//
//  SceneDelegate.h
//  PromptView
//
//  Created by 高志炎(Intretech) on 2023/8/28.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

