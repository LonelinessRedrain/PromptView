//
//  CommonUtils.h
//  XG_Student
//
//  Created by 12990 on 2019/3/13.
//  Copyright © 2019 intretech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "QMUICommonDefines.h"

NS_ASSUME_NONNULL_BEGIN

@interface CommonUtils : NSObject

#pragma mark - Foundation

/// 获取当前时间戳（单位毫秒）
+ (NSString *)currentTimestamp;

/// 获取当前时间戳（单位秒）
+ (NSString *)currentTimestampBySecond;

/// 根据指定格式字符串获取时间，默认为"yyyy/MM/dd hh:mm:ss SS"
+ (NSString *)currentTimeStringWithDateFormat:(nullable NSString *)dateFormat;

/// 获取时间字符串
/// @param date date
/// @param dateFormat 格式化时间
+ (NSString *)timeStringWitDate:(NSDate *)date dateFormat:(nullable NSString *)dateFormat;

/// 将时间转换为时间戳
+ (NSString *)getOtherTimeStrWithString:(NSString *)formatTime;

/// NSDate转换成时间戳（单位秒）
/// @param date NSDate对象
+ (NSString *)timestampWithDate:(NSDate *)date;

/// 时间戳（单位秒）转换成NSDate
/// @param timestamp 时间戳
+ (NSDate *)dateWithTimestamp:(NSString *)timestamp;

/// 将传入时间转为固定格式
+ (NSString *)fetchTimeStringWithDateFormat:(nullable NSString *)dateFormat;

/// 时间字符串转换成时间
/// @param dateString 时间字符串
/// @param dateFormat 格式化类型
+ (NSDate *)dateWithDatestring:(NSString *)dateString dateFormat:(NSString *)dateFormat;

/// 把秒数转换成 hh:mm:ss格式
/// @param seconds 秒数
+ (NSString *)convertSecondsToHHMMSS:(NSInteger)seconds;

/// 预览图片(view生成图片后预览效果)
+ (void)previewWithImage:(UIImage *)image;

+ (void)previewWithImages:(NSMutableArray *)images originalImage:(UIImage *)originalImage;

/// 从中文获取拼音
+ (NSString *)pinyinFromChinese:(NSString *)chinese;

/// 从中文获取拼音首字母
+ (NSString *)firstLetterFromChinese:(NSString *)chinese;

/// userDefault getObject
+ (id)userDefaultObjectForKey:(NSString *)defaultName;

/// userDefault setObject
+ (void)userDefaultSetObject:(id)value forKey:(NSString *)defaultName;

/// userDefault getObject(带userId分用户储存)
+ (id)userDefaultWithUserIdObjectForKey:(NSString *)defaultName;

/// userDefault setObject(带userId分用户储存)
+ (void)userDefaultWithUserIdSetObject:(id)value forKey:(NSString *)defaultName;

/// 是否是空对象
+ (BOOL)isNullObject:(id)object;

/// 是否为空字符串
+ (BOOL)isEmptyString:(NSString *)string;

/// 是否为空富文本
+ (BOOL)isEmptyAttributedString:(NSAttributedString *)string;

//判断内容是否全部为空格 yes 全部为空格 no 不是
+ (BOOL)isEmptyBlankSpace:(NSString *)str;

/// 字符串是否全是数字
+ (BOOL)isPureNumber:(NSString *)string;

/// 特殊符号替换，用于打印不出来的字符
/// @param oriString 原始字符
+ (NSString *)dealWithSpecialSymbol:(NSString *)oriString;

/// 密码是否有效，有效密码不能是纯数字 or 纯密码
/// @param password 原密码
+ (BOOL)isValidPassword:(NSString *)password;

/// 获取最小差值的绝对值
/// @param subtracter 被减数
/// @param minuends 减数数组
+ (CGFloat)getMinimumDifferenceABSWithSubtracter:(CGFloat)subtracter minuends:(NSArray<NSNumber *> *)minuends;

/// 检查网络状态
/// @param notReachableBlock 网络不可达回调
/// @param WWANBlock 手机网络状态回调
/// @param WiFiBlock WiFi状态回调
+ (void)checkNetworkStatusWithNotReachableBlock:(nullable void(^)(void))notReachableBlock WWANBlock:(nullable void(^)(void))WWANBlock WiFiBlock:(nullable void(^)(void))WiFiBlock;

/// 显示网络不可达弹窗
+ (void)showNetworkNotReachableToast;

/// 获取学段名
/// @param grade 学段类型
+ (NSString *)sectionNameWithGrade:(NSInteger)grade;

/// 添加内容到剪贴板
/// @param string 字符串
+ (void)addContentToPasteboard:(NSString *)string;
 

/// 保留两位小数，不进行四舍五入（系统默认会进行四舍六入五等待法）
/// @param number 数字
+ (CGFloat)numberByCutToTwoDecimalsWithoutRound:(CGFloat)number;

/// 生成随机字符串
/// @param length 长度
+ (NSString *)randomStringWithLength:(int)length;

/// 生成数据库使用的随机字符串
+ (NSString *)randomStringForDataBase;

#pragma mark - 系统相关
/// 获取设备唯一标识符，默认存储在keychain中，仅当用户格式化手机且没有恢复钥匙串数据时会改变
+ (NSString *)getDeviceUUID;

/// 获取移动设备名称
+ (NSString *)getDeviceName;

/// 获取移动设备版本
+ (NSString *)getDeviceVersion;

/// 获取移动设备电量
+ (CGFloat)getBatteryLevel;

/// 获取App版本
+ (NSInteger)fetchCurrVersion;

/// 检查相机授权情况
/// @param authorizationStatus 授权状态 granted = YES代表已授权
+ (void)checkCameraAuthorizationStatus:(void (^)(BOOL granted))authorizationStatus;

/// 检查相册授权情况
/// @param authorizationStatus 授权状态 granted = YES代表已授权
+ (void)checkPhotoAlbumAuthorizationStatus:(void (^)(BOOL granted))authorizationStatus;

#pragma mark - UIKit

/// 获取imageView数组
/// @param view 父亲视图
+ (NSArray<UIImageView *> *)getImageViewsFromParentView:(UIView *)view;

/// 获取Button
+ (UIButton *)buttonWithTitle:(NSString *)title titleColor:(UIColor *)titleColor fontSize:(CGFloat)fontSize target:(id)target action:(SEL)action;

/// 获取Button 包含设置背景色
+ (UIButton *)buttonWithTitle:(NSString *)title titleColor:(UIColor *)titleColor fontSize:(CGFloat)fontSize backgroundColor:(UIColor *)bgColor cornerRadius:(CGFloat)cornerRadius target:(id)target action:(SEL)action;

/// 获取Label
+ (UILabel *)labelWithText:(NSString *)text textColor:(UIColor *)textColor fontSize:(CGFloat)fontSize;

+ (UIViewController *)topViewController;

/// 视图360度旋转动画
+ (void)rotateAnimationWithView:(UIView *)view;

/// 生成二维码，中间是黑白的咕咕机Logo
/// @param text 文本
/// @param size 二维码尺寸
+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size;

/// 生成二维码，中间是黑白的咕咕机Logo
/// @param text 文本
/// @param size 二维码尺寸
/// @param logoFrame Logo位置
+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size logoFrame:(CGRect)logoFrame;

///  生成打印使用的二维码，两边是白色的。中间1/3是二维码。
/// @param text 图片
+ (UIImage *)createPrintQRCodeWithText:(NSString *)text;

/// 生成二维码
/// @param text 文本
/// @param size 二维码尺寸
/// @param image 二维码中间的图片
+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size image:(UIImage *)image;


/// 生成二维码
/// @param text 文本
/// @param size 二维码尺寸
/// @param image 二维码中间的图片
/// @param imageFrame 二维码中间的图片位置
+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size image:(UIImage *)image imageFrame:(CGRect)imageFrame;

/// 生成条形码
/// @param text 文本
/// @param size 尺寸
+ (UIImage *)createBarCode:(NSString *)text size:(CGSize)size;

#pragma mark - Thrid party

/// 获取导航栏返回按钮
+ (UIBarButtonItem *)backBarButtonItemWithTarget:(id)target action:(SEL)action;

/// 获取导航栏取消按钮
+ (UIBarButtonItem *)cancelBarButtonItemWithTarget:(id)target action:(SEL)action;

/// string转成dictionary
+ (NSDictionary *)dictionaryFromJsonString:(NSString *)jsonString;

/// dict转成string
+ (NSString *)stringFromDictionary:(NSDictionary *)dict;


#pragma mark - file

/// 获取文件大小
+ (NSString *)fileSizeFromPath:(NSString *)path;

/// 获取文件创建时间戳
+ (NSString *)fileCreateTimestampFromPath:(NSString *)path;

/// 获取文件创建日期
+ (NSString *)fileCreateDateFromPath:(NSString *)path;

/// 获取文件名
+ (NSString *)fileNameFromPath:(NSString *)path;

#pragma mark - 埋点
/// 友盟埋点
/// @param eventID ID
+ (void)umTrackWithEventID:(NSString *)eventID;

/// 友盟埋点带分类，例如：点击tab是ID，“学习”，“发现”，“我的”为分类
/// @param eventID ID
/// @param category 分类
+ (void)umTrackWithEventID:(NSString *)eventID category:(NSString *)category;

/// 友盟埋点带分类，按类型统计
/// @param eventID ID
/// @param type 类型（该字段暂时无用，留供以后扩展使用）
+ (void)umTrackWithEventID:(NSString *)eventID type:(NSInteger)type;
#pragma mark - 网络
/// 网络是否可用
+ (BOOL)isNetworkReachability;

/// 获取当前的Wi-Fi名称
+ (NSString *)currentWifiSSID;

+ (BOOL)isReachableViaWiFi;

+ (BOOL)isReachableViaWWAN;

#pragma mark - 获取ip地址
+ (NSString *)getIPAddress;

#pragma mark - 版本判断

/// 判断是否是某个系统版本
/// @param versionString 版本字符串
+ (BOOL)isSystemVersionWithVersionString:(NSString *)versionString;

#pragma mark - 请求照片权限，注意，强烈要求用户获得照片权限，否则视频写入照片会有崩溃

typedef void(^RequestAssetsLibraryAuthCompletion)(BOOL isAuth);

+ (void)requestALAssetsLibraryAuthorizationWithCompletion:(RequestAssetsLibraryAuthCompletion) requestAssetsLibraryAuthCompletion;

// 获取当前屏幕显示的viewcontroller
+ (UIViewController*)currentViewController;

/// Toast
/// @param title    标题
+ (void)MBProgressHUDWithTitle:(NSString *)title;

/// Toast
/// @param title 标题
/// @param delayTime 消失时常
+ (void)MBProgressHUDWithTitle:(NSString *)title delayTime:(CGFloat)delayTime;

#pragma mark -  URL Scheme

/// 跳转QQ App的群页面
/// @param qqGroupID QQ群ID
+ (void)jumpToQQGroupPageWithQQGroupID:(NSString *)qqGroupID;


/**
 使用imageIO中的api生成data UIImage 转 NSData 
 */
- (NSData *)rawData2:(UIImage *)image;

/// 比较两个浮点数的大小返回的是startValue与endValue对比的结果
/// - Parameters:
///   - startValue: startValue
///   - endValue: endValue
///   - position: 两个浮点数的精度
///   - roundingMode: 精度规则
+ (NSComparisonResult)compareStartValue:(CGFloat)startValue endValue:(CGFloat)endValue afterPoint:(int)position roundingMode:(NSRoundingMode)roundingMode;

/// 浮点数取精度
/// - Parameters:
///   - floatValue: 数值
///   - position: 精度
///   - roundingMode: 精度规则
+ (CGFloat)floatValue:(CGFloat)floatValue afterPoint:(int)position roundingMode:(NSRoundingMode)roundingMode;
@end

NS_ASSUME_NONNULL_END
