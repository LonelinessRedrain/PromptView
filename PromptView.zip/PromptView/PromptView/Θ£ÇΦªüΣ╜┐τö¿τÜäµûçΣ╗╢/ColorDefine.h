//
//  ColorDefine.h
//  XG
//
//  Created by deejan on 15/7/14.
//  Copyright (c) 2015年 memobird. All rights reserved.
//

#import "UIColor+YYAdd.h"

#ifndef XG_ColorDefine_h
#define XG_ColorDefine_h

#define kProjectColorNewGreen [UIColor colorWithHexString:@"#1BCFC8"] //新主题颜色
#define kProjectColorGreen [UIColor colorWithHexString:@"#1acfc9"] //主题颜色
#define kProjectTextColor [UIColor colorWithHexString:@"#333333"] //默认字体颜色
#define kProjectBackgroundColorGray [UIColor colorWithHexString:@"F5F5F8"] //灰色背景颜色
#define kProjectLightTextColor [UIColor colorWithHexString:@"#999999"] //浅色字体颜色
#define kProjectDarkGrayTextColor [UIColor colorWithHexString:@"#666666"] //深色字体颜色
#define kProjectBorderGrayTextColor [UIColor colorWithHexString:@"#E6E6E6"] //按钮灰色边框颜色
#define kProjectLineGrayColor [UIColor colorWithHexString:@"#e2e2e2"] //灰色分割线
#define kProjectDEDEDELineGrayColor [UIColor colorWithHexString:@"#DEDEDE"] //灰色分割线
#define kProjectButtonRedColor [UIColor colorWithHexString:@"#ff7285"] //红色按钮
#define kProjectButtonHighlightedRedColor [UIColor colorWithHexString:@"#ce606f"] //红色按钮
#define KProjectButtonHighlightGreen [UIColor colorWithHexString:@"#00bab4"]    // 主题色按钮高亮颜色
#define KProjectButtonDisabledGreen [UIColor colorWithHexString:@"#EBEBEB"]    // 主题色按钮不可用颜色
#define kProjectLayerBorderColor [UIColor colorWithHexString:@"#c8c8c8"]
#define kProjectLayerE5E5E5BorderColor [UIColor colorWithHexString:@"#E5E5E5"]
#define kProjectColorBlue [UIColor colorWithHexString:@"#486ea8"] //蓝色
#define kProjectUnderlineColor [UIColor colorWithHexString:@"#CBC9C9"] // 灰
#define KProjectBackGroundColor [UIColor colorWithHexString:@"#F5F5F8"]    // 背景灰色
#define KProjectButtonDisabledTitleGreen [UIColor colorWithHexString:@"#FFFFFF"]    // 钮不可用文本颜色
#define KProjectGrayBorderColor [UIColor colorWithHexString:@"#EDEDED"]    // 灰色边框
#define KProjectF6F8F9GrayBackGroundColor [UIColor colorWithHexString:@"#F6F8F9"]  // 灰色背景
#define KProjectFAFAFAGrayBackGroundColor [UIColor colorWithHexString:@"#FAFAFA"]  // 灰色背景
#define KProjectFAFAFBGrayBackGroundColor [UIColor colorWithHexString:@"#FAFAFB"]  // 灰色背景

#define KProjectLightGreenBackGroundColor [UIColor colorWithHexString:@"#EDFDFA"]  // 浅绿色背景

#define KProject777777GrayColor [UIColor colorWithHexString:@"#777777"]  // 灰色字体
#define KProject888888GrayColor [UIColor colorWithHexString:@"#888888"]  // 灰色字体
#define KProjectBorderColorECECEC [UIColor colorWithHexString:@"#ECECEC"]  // 边框色
#endif
