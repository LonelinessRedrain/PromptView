//
//  PromptMultipleSelectTableViewCell.h
//  XG_Student
//
//  Created by 高志炎(Intretech) on 2022/11/18.
//  Copyright © 2022 intretech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QMUIKit.h"
#import "QMUICommonDefines.h"
#import "CommonUtils.h"
#import "ColorDefine.h"
#import "Macro.h"

NS_ASSUME_NONNULL_BEGIN

@interface PromptMultipleSelectTableViewCell : UITableViewCell
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UIImageView *selectImageView;
/// 横向
@property (nonatomic, strong) UIView *lineView;
@end

NS_ASSUME_NONNULL_END
