//
//  PromptView.h
//  XG_Student
//
//  Created by Gzy on 2019/2/15.
//  Copyright © 2019 intretech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QMUIKit.h"
#import "QMUICommonDefines.h"
#import "CommonUtils.h"
#import "ColorDefine.h"
#import "Macro.h"

@class PromptView;

typedef NS_ENUM(NSInteger, PromptViewActionStyle) {
    PromptViewActionStyleDefault = 0,
    PromptViewActionStyleCancel,
    PromptViewActionStyleDestructive
};

///弹窗类型
typedef NS_ENUM(NSInteger, PromptViewStyle) {
    PromptViewStylePlainText = 0,
    PromptViewStylePureImage,
    PromptViewStyleImageText,
    PromptViewStyleMultipleChoice,
    PromptViewStyleCustom
};

@interface PromptViewAction : NSObject

/**
 *  初始化`PromptView`的按钮
 *
 *  @param title   按钮标题
 *  @param style   按钮style，跟系统一样，有 Default、Cancel、Destructive 三种类型
 *  @param handler 处理点击事件的block，注意 PromptViewAction 点击后必定会隐藏 PromptView，不需要手动在 handler 里 hide
 *
 *  @return PromptView按钮的实例
 */
+ (_Nonnull instancetype)actionWithTitle:(nullable NSString *)title style:(PromptViewActionStyle)style handler:(nullable void (^)(PromptViewAction * _Nonnull action))handler;

/// `PromptViewAction`对应的 button 对象
@property(nonatomic, strong) UIButton * _Nonnull button;

/// `PromptViewAction`对应的标题
@property(nullable, nonatomic, copy, readonly) NSString *title;

/// `PromptViewAction`对应的样式
@property(nonatomic, assign, readonly) PromptViewActionStyle style;

/// `PromptViewAction`是否允许操作
@property(nonatomic, assign, getter=isEnabled) BOOL enabled;

/// `PromptViewAction`是否点击后关闭弹窗,默认为yes
@property(nonatomic, assign, getter=isTapHide) BOOL tapHide;

@end

// 便携设备类型
typedef NS_ENUM(NSInteger, PromptViewButtonGuidType) {
    PromptViewButtonGuidTypeDefault,           // 默认引导，即取消按钮和确认按钮为默认(蓝色)状态
    PromptViewButtonGuidTypeConfirm,        // 确定按钮引导，即取消按钮为灰色，确认按钮为默认(蓝色)状态
    PromptViewButtonGuidTypeCancel,         // 取消按钮引导，即取消按钮为默认(蓝色)状态，确认按钮为灰色
    PromptViewButtonGuidTypeAll
};

@class YYTextView;
@class PromptButton;

typedef void (^PromptConfirmBlock) (void);
typedef void (^PrompttableConfirmBlock) (NSString * _Nullable textFieldString);  // 新增科目确定回调
typedef void (^PromptTransConfirmBlock) (NSInteger tag);              // 课表打印方向设置回调
typedef void (^PromptCancelBlock) (void);
typedef void (^PromptCloseBlock) (void);

typedef void (^PromptDidSelectImageBlock) (NSString * _Nonnull url);

@interface PromptView : UIView

@property (nonatomic, copy) PromptConfirmBlock _Nullable confirmBlock;
@property (nonatomic, copy) PrompttableConfirmBlock _Nullable tableConfirmBlock;
@property (nonatomic, copy) PromptTransConfirmBlock _Nullable transConfirmBlock;

@property (nonatomic, copy) PromptCancelBlock _Nullable cancelBlock;
@property (nonatomic, copy) PromptCloseBlock _Nullable closeBlock;
@property (nonatomic, copy) PromptCloseBlock _Nullable tapBgBlock;
/**
 确定按钮
 */
@property (nonatomic, strong) UIButton * _Nullable confirmButton;

/**
 取消按钮
 */
@property (nonatomic, strong) UIButton * _Nullable cancelButton;

@property (nonatomic, copy) PromptDidSelectImageBlock _Nullable didSelectImageBlock;

/// `PromptView`对应的标题
@property(nonnull, nonatomic, copy) NSString * title;
/// `PromptView`对应的标题颜色
@property (nonatomic, strong) UIColor * _Nullable titleColor;
/// `PromptView`对应的标题字体
@property (nonatomic, strong) UIFont * _Nullable titleFont;

/// `PromptView`对应的message
@property(nonnull, nonatomic, copy) NSString * message;
/// `PromptView`对应的message颜色
@property (nonatomic, strong) UIColor * _Nullable messageColor;
/// `PromptView`对应的message字体
@property (nonatomic, strong) UIFont * _Nullable messageFont;

/// `PromptView`对应的样式
@property(nonatomic, assign) PromptViewStyle style;

///文本对齐方式
@property (nonatomic, assign) NSTextAlignment textAlignment;

/// 标题titleLabel的富文本中是否有可点击文字,默认NO
@property(nonatomic, assign) BOOL titleLabelHasClickableText;

/// messageLabel的富文本中是否有可点击文字,默认NO
@property(nonatomic, assign) BOOL messageLabelHasClickableText;

/// `PromptView`对应的主题颜色，默认为app主题颜色
@property (nonatomic, strong) UIColor * _Nullable themeColor;

/// 是否点击灰色区域后关闭弹窗,默认为yes
@property(nonatomic, assign, getter=isTapBackgroundHide) BOOL tapBackgroundHide;

/// 当前所有通过`addTextFieldWithConfigurationHandler:`接口添加的输入框
@property(nullable, nonatomic, copy, readonly) NSArray <UITextField *> *textFields;

/// 是否过滤空格,默认YES
@property(nonatomic, assign) BOOL isFilterWihtespace;

/// 是否允许输入空格,默认YES
@property(nonatomic, assign) BOOL isAllowInputWihtespace;

///tableView的cell之间的间距，默认为0，没有间距
@property (nonatomic, assign) NSUInteger spacingBetweenCell;

/// 是否有logo图片,默认NO
@property(nonatomic, assign) BOOL hasLogo;
@property (nonatomic, copy) NSString * _Nullable logoImageName;
/// logo底部约束,默认为16
@property(nonatomic, assign) CGFloat logoBottom;

/// 是否有右上角关闭按钮,默认NO
@property(nonatomic, assign) BOOL hasClose;

@property (nonatomic, copy) NSString * _Nullable bgImageName;
/// 当前所有通过`addTextViewWithConfigurationHandler:`接口添加的输入框
@property (nonatomic, strong) QMUITextView * _Nullable textView;

///分段选择弹窗，打印内容选择弹窗
+ (nonnull PromptView *)promptViewSegmentedWithTitle:(NSString * _Nullable)title
                                            segments:(NSArray<NSString *> * _Nonnull)segments
                                     selectedSegment:(NSInteger)selectedSegment
                                     addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                                          confirmStr:(NSString * _Nullable)confirmStr
                                             confirm:(void (^_Nullable)(BOOL isSelected, NSUInteger selectedSegment))completeHandler
                                           cancelStr:(NSString * _Nullable)cancelStr
                                              cancel:(PromptCancelBlock _Nullable)cancelBlock;

///纯图片弹窗，首页广告图弹窗
+ (nonnull PromptView *)promptViewPureImageWithUrl:(NSString * _Nonnull)url
                                    didSelectImage:(void (^_Nullable)(NSString * _Nonnull url))didSelectHandler
                                           confirm:(PromptConfirmBlock _Nullable)confirmBlock;

///打印方向选择
+ (nonnull PromptView *)promptViewPrintDirectionWithTitle:(NSString * _Nullable)title
                                                  message:(NSString * _Nullable)message
                                               confirmStr:(NSString * _Nullable)confirmStr
                                                  confirm:(void (^_Nullable)(NSInteger tag))completeHandler
                                                cancelStr:(NSString * _Nullable)cancelStr
                                                   cancel:(PromptCancelBlock _Nullable)cancelBlock;

///好友信息备注弹窗
+ (nonnull PromptView *)promptViewWithImageURL:(NSString * _Nullable)imageURL
                                         title:(NSString * _Nullable)title
                                       message:(NSString * _Nullable)message
                                    confirmStr:(NSString * _Nullable)confirmStr
                                       confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                     cancelStr:(NSString * _Nullable)cancelStr
                                        cancel:(PromptCancelBlock _Nullable)cancelBlock;

///自定义图片提示弹窗
+ (nonnull PromptView *)promptViewWithImageName:(NSString * _Nullable)imageName
                                      imageText:(NSString * _Nullable)imageText
                                     confirmStr:(NSString * _Nullable)confirmStr
                                        confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                      cancelStr:(NSString * _Nullable)cancelStr
                                         cancel:(PromptCancelBlock _Nullable)cancelBlock;

///选择弹窗，无message
+ (nonnull PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                                 dataSource:(NSArray * _Nonnull)dataSource
                         selectedDataSource:(NSArray * _Nullable)selectedDataSource
                         isMultipleSelected:(BOOL)isMultipleSelected
                            addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(NSArray * _Nullable selecteds, BOOL isChecked))completeHandler
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

///选择弹窗，有message
+ (nonnull PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                                    message:(NSString * _Nullable)message
                                 dataSource:(NSArray * _Nonnull)dataSource
                         selectedDataSource:(NSArray * _Nullable)selectedDataSource
                         isMultipleSelected:(BOOL)isMultipleSelected
                            addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(NSArray * _Nullable selecteds, BOOL isChecked))completeHandler
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

///选择弹窗
+ (nonnull PromptView *)subPromptViewWithTitle:(NSString * _Nullable)title
                                 dataSource:(NSArray * _Nonnull)dataSource
                         selectedDataSource:(NSArray * _Nullable)selectedDataSource
                         isMultipleSelected:(BOOL)isMultipleSelected
                            addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(NSArray * _Nullable selecteds, BOOL isChecked))completeHandler
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

///简单标题单按钮弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock;

///简单标题弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

///简单文字弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                    message:(id _Nullable)message
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

/// 有关闭按钮无取消按钮的简单文字弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                    message:(id _Nullable)message
                                   hasClose:(BOOL)hasClose
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock;
/// 有关闭按钮和有取消按钮的简单文字弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                    message:(id _Nullable)message
                                   hasClose:(BOOL)hasClose
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

/// 文字弹窗
/// @param title 标题
/// @param message 信息
/// @param hasClose 是否有关闭按钮
/// @param confirmStr 确认按钮标题
/// @param confirmBlock 确认按钮回调
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                    message:(id _Nullable)message
                              logoImageName:(NSString * _Nullable)logoImageName
                                   hasClose:(BOOL)hasClose
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

/// 有logo图片弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                    message:(id _Nullable)message
                              logoImageName:(NSString * _Nullable)logoImageName
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

/// 录音名称弹窗
+ (nonnull PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                                    message:(NSString * _Nullable)message
                                limitLength:(NSUInteger)limitLength
                               addTextField:(void (^_Nullable)(UITextField * _Nonnull textField))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(NSString * _Nonnull text))completeHandler;

/// 用户协议弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                    message:(id _Nullable)message
                                bgImageName:(NSString * _Nullable)imageName
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock;

/// 文字二维码，生成二维码
+ (nonnull PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                                    codeType:(NSUInteger)codeType
                                limitLength:(NSUInteger)limitLength
                                addTextView:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(UIImage * _Nonnull image))completeHandler;

/// textView弹窗
+ (nonnull PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                                    message:(NSString * _Nullable)message
                                limitLength:(NSUInteger)limitLength
                                addTextView:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(NSString * _Nonnull text))completeHandler;

///双主题颜色按钮弹窗
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  otherStr:(NSString * _Nullable)otherStr
                                      other:(PromptConfirmBlock _Nullable)otherBlock;

+ (nonnull instancetype)promptViewWithTitle:(NSString * _Nullable)title
                                    message:(NSString * _Nullable)message
                             preferredStyle:(PromptViewStyle)preferredStyle;

+ (nonnull instancetype)promptViewWithAttrTitle:(NSAttributedString * _Nullable)title
                                        message:(NSAttributedString * _Nullable)message
                                 preferredStyle:(PromptViewStyle)preferredStyle;

- (nonnull instancetype)initWithTitle:(id _Nullable)title
                              message:(id _Nullable)message
                       preferredStyle:(PromptViewStyle)preferredStyle;

/// 增加一个按钮
- (void)addAction:(nonnull PromptViewAction *)action;

// 增加一个“取消”按钮，点击后 PromptView 会被 hide
- (void)addCancelAction;

/// 增加一个输入框
- (void)addTextFieldWithConfigurationHandler:(void (^_Nullable)(UITextField * _Nonnull textField))configurationHandler;

/// 增加一个输入框
/// @param length 大于0时候代表有限制字符数，不等于0时代表“确定”按钮需要置灰
/// @param configurationHandler textField配置
- (void)addTextFieldWithLimitLength:(NSInteger)length configurationHandler:(void (^_Nullable)(UITextField * _Nonnull textField))configurationHandler;

/// 增加一个TextView
- (void)addTextViewWithConfigurationHandler:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler;

/// 增加一个TextView,限制最大字数
/// @param length 大于0时候代表有限制字符数，不等于0时代表“确定”按钮需要置灰
/// @param configurationHandler textView配置
- (void)addTextViewWithLimitLength:(NSInteger)length configurationHandler:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler;

/// 增加一个SelectButton
- (void)addSelectButtonWithConfigurationHandler:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler;

/// 增加一个自定义的view作为`PromptView`的customView
- (void)addCustomView:(UIView *_Nullable)view;

/// 显示`PromptView`
- (void)showWithAnimated:(BOOL)animated;

/// 隐藏`PromptView`
- (void)hideWithAnimated:(BOOL)animated;

/**
 添加到当前视图
 */
- (void)show;

/**
 从当前视图移除
 */
- (void)dimiss;

@end
