//
//  PromptView.m
//  XG_Student
//
//  Created by Wcs on 2019/2/15.
//  Copyright © 2019 intretech. All rights reserved.
//

#import "PromptView.h"
#import "YYLabel.h"
#import "QMUITextField.h"

//#import "UILabel+AdjustFont.h"

#import "PromptMultipleSelectTableViewCell.h"

#define DissmissPromptViewNotificationKey @"DissmissPromptViewNotificationKey"

///通用顶部间距
#define TopSpace 31.0
///通用底部间距
#define BottomSpace 21.0
///通用底部间距
#define MiddleSpace 23.0

#define kAnimationDuration 0.2

@interface PromptView ()<UITextFieldDelegate,UITextViewDelegate,UITableViewDataSource,UITableViewDelegate,QMUITextViewDelegate>

@property (nonatomic, strong) UIView *contentView;

@property (nonatomic, strong) NSMutableArray * addTextFields;
/**
 关闭按钮
 */
@property (nonatomic, strong) UIButton *closeButton;

/**
 内容Label
 */
@property (nonatomic, strong) YYLabel *detailLabel;

/**
 标题
 */
@property (nonatomic, strong) UILabel *titleLabel;
///信息
@property (nonatomic, strong) UILabel * messageLabel;

@property(nonatomic, strong) PromptViewAction *cancelAction;

@property (nonatomic, strong) PromptViewAction * confirmAction;

@property(nonatomic, strong) NSMutableArray<PromptViewAction *> *addActions;

/**
 背景imageView
 */
@property (nonatomic, strong) UIImageView *bgImageView;

@property (nonatomic, strong) UIImageView *logoImageView;

// 新增课程文本
@property (nonatomic, copy) NSString *courseString;

//字数显示
@property (nonatomic, strong) UILabel *countLabel;

//用户选中的打印方式
@property (nonatomic, assign) NSInteger selectTag;

// 横向图片
@property (nonatomic, strong) UIImageView *transverseImageView;

// 竖向图片
@property (nonatomic, strong) UIImageView *verticalImageView;

// 打原文
@property (nonatomic, strong) UIButton *originalButton;

// 打其它
@property (nonatomic, strong) UIButton *othersButton;

// 打全部
@property (nonatomic, strong) UIButton *allButton;


///输入字数限制最大长度
@property (nonatomic, assign) NSUInteger maxLength;
///内容高度
@property (nonatomic, assign) CGFloat contentHeight;
///打勾按钮
@property (nonatomic, strong) UIButton * selectButton;
///多选表
@property (nonatomic, strong) UITableView * tableView;
///多选数据源
@property (nonatomic, strong) NSArray * dataSource;
///多选已选中的数据源
@property (nonatomic, strong) NSMutableArray * selectedDataSource;
///是否多选
@property (nonatomic, assign) BOOL isMultipleSelect;

// 图片
@property (nonatomic, strong) UIImageView *imageView;

// 图片地址
@property (nonatomic, strong) NSString *imageUrl;
///自定义View
@property (nonatomic, strong) UIView * customView;
///已选中的分段
@property (nonatomic, assign) NSUInteger selectedSegment;
///分段数据源
@property (nonatomic, strong) NSArray * segments;
///分段按钮数组
@property (nonatomic, strong) NSMutableArray * segmentButtons;
@end

@implementation PromptView

@synthesize selectedDataSource = _selectedDataSource;

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

#pragma mark -- 限制输入字数

- (void)textFieldTextChange:(UITextField *)textField {
    if ((textField.tag == 1||textField.tag == self.addTextFields.count)&&self.maxLength != 0) {
        [self limitInputWithInputView:textField];
    }
    self.courseString = textField.text;
    if (self.isFilterWihtespace) {
        self.confirmAction.button.enabled = [CommonUtils isEmptyBlankSpace:textField.text] ? NO : YES;
        self.cancelButton.enabled = [CommonUtils isEmptyBlankSpace:textField.text] ? NO : YES;
    } else {
        self.confirmAction.button.enabled = textField.text.length == 0 ? NO : YES;
        self.cancelButton.enabled = textField.text.length == 0 ? NO : YES;
    }
}

- (void)limitInputWithInputView:(UIView *)inputView {
    UITextField * textField = (UITextField *)inputView;
    NSInteger kMaxLength = self.maxLength;
    NSString *toBeString = textField.text;
    NSString *lang = [[UIApplication sharedApplication]textInputMode].primaryLanguage; //ios7之前使用[UITextInputMode currentInputMode].primaryLanguage
    if ([lang isEqualToString:@"zh-Hans"]) { //中文输入
        UITextRange *selectedRange = [textField markedTextRange];
        //获取高亮部分
        UITextPosition *position = [textField positionFromPosition:selectedRange.start offset:0];
        if (!position) {// 没有高亮选择的字，则对已输入的文字进行字数统计和限制]
            if (toBeString.length > kMaxLength) {
                self.countLabel.text = [NSString stringWithFormat:@"%lu/%lu",kMaxLength,kMaxLength];
                textField.text = [toBeString substringToIndex:kMaxLength];
//                [textField resignFirstResponder];
                ShowToast(@"长度达到限制");
            } else {
//                textField.text =[textField.text stringByReplacingOccurrencesOfString:@" " withString:@""];
                self.countLabel.text = [NSString stringWithFormat:@"%lu/%lu",(unsigned long)textField.text.length,kMaxLength];
            }
        } else {//有高亮选择的字符串，则暂不对文字进行统计和限制
            
        }
    } else {//中文输入法以外的直接对其统计限制即可，不考虑其他语种情况
        if(toBeString.length > kMaxLength) {
            self.countLabel.text = [NSString stringWithFormat:@"%lu/%lu",kMaxLength,kMaxLength];
            textField.text = [toBeString substringToIndex:kMaxLength];
            
        } else {
            self.countLabel.text = [NSString stringWithFormat:@"%lu/%lu",(unsigned long)textField.text.length,kMaxLength];
        }
    }
}

#pragma mark - 新版项目全局弹窗

+ (PromptView *)promptViewSegmentedWithTitle:(NSString *)title
                                    segments:(NSArray<NSString *> *)segments
                             selectedSegment:(NSInteger)selectedSegment
                             addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                                  confirmStr:(NSString *)confirmStr
                                     confirm:(void (^_Nullable)(BOOL isSelected, NSUInteger selectedSegment))completeHandler
                                   cancelStr:(NSString *)cancelStr
                                      cancel:(PromptCancelBlock)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:nil preferredStyle:PromptViewStyleCustom];
    promptView.selectedSegment = selectedSegment;
    promptView.segments = segments;
    
    CGFloat segmentMiddle = FIT_LENGTH_PT(12);
    CGFloat segmentButtonHeight = 42.0;
    CGFloat segmentButtonWidth = FIT_LENGTH_PT(81);///
    CGFloat segmentLeftRight = (FIT_LENGTH_PT(305) - segments.count*segmentButtonWidth - (segments.count - 1)*segmentMiddle)/2.0;
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, segmentButtonHeight)];
    contentView.backgroundColor = [UIColor clearColor];
    
    __block UIButton * lastButton = nil;
    [segments enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.showsTouchWhenHighlighted = false;
        [button setTitle:obj forState:UIControlStateNormal];
        [button.titleLabel setFont:[UIFont systemFontOfSize:FIT_LENGTH_PT(15)]];
        [button setTitleColor:kProjectTextColor forState:UIControlStateNormal];
        [button setTitleColor:kProjectColorNewGreen forState:UIControlStateSelected];
        [button setBackgroundImage:[UIImage imageWithColor:kProjectColorNewGreen] forState:UIControlStateHighlighted];
        [button setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHexString:@"#FAFAFB"]] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHexString:@"#E5FFFE"]] forState:UIControlStateSelected];
        button.layer.borderColor = [UIColor colorWithHexString:@"#E5E5E5"].CGColor;
        button.layer.borderWidth = 1;
        [button.layer setCornerRadius:FIT_LENGTH_PT(8)];
        button.layer.masksToBounds = YES;
        [button addTarget:promptView
                   action:@selector(segmentButtonClick:)
         forControlEvents:UIControlEventTouchUpInside];
        if (selectedSegment < 0) {
            button.selected = YES;
            button.layer.borderWidth = 0;
            [button setTitleColor:[UIColor colorWithHexString:@"#FA4A4A"] forState:UIControlStateSelected];
            [button setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHexString:@"#FFD9DE"]] forState:UIControlStateHighlighted];
            [button setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHexString:@"#FFD9DE"]] forState:UIControlStateSelected];
        } else {
            button.selected = idx == selectedSegment;
            button.layer.borderWidth = idx == selectedSegment?0:1;
        }
        button.tag = idx;
        [promptView.segmentButtons addObject:button];
        [contentView addSubview:button];
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            if (lastButton == nil) {
                make.left.mas_equalTo(contentView).offset(segmentLeftRight);
            } else {
                make.left.mas_equalTo(lastButton.mas_right).offset(segmentMiddle);
            }
            make.centerY.mas_equalTo(contentView);
            make.size.mas_equalTo(CGSizeMake(segmentButtonWidth, segmentButtonHeight));
        }];
        lastButton = button;
    }];
    
    [promptView addCustomView:contentView];
    
    if (configurationHandler) {
        [promptView addSelectButtonWithConfigurationHandler:^(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel) {
            configurationHandler(selectButton, selectLabel);
        }];
    }
    if (![CommonUtils isEmptyString:cancelStr]) {
        [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
            if (cancelBlock) {
                cancelBlock();
            }
        }]];
    }
    __weak __typeof(&*promptView) weakPromptView = promptView;
    [promptView addAction:[PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (completeHandler) {
            completeHandler(weakPromptView.selectButton.isSelected, weakPromptView.selectedSegment);
        }
    }]];
    return promptView;
}

+ (PromptView *)promptViewPureImageWithUrl:(NSString *)url
                            didSelectImage:(void (^_Nullable)(NSString * url))didSelectHandler
                                   confirm:(PromptConfirmBlock _Nullable)confirmBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:nil message:nil imageName:url preferredStyle:PromptViewStylePureImage];
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:promptView action:@selector(didSelectImage:)];
    [promptView.imageView addGestureRecognizer:tap];
    promptView.didSelectImageBlock = ^(NSString *url) {
        if (didSelectHandler) {
            didSelectHandler(url);
        }
    };
    promptView.confirmBlock = ^{
        if (confirmBlock) {
            confirmBlock();
        }
    };
    return promptView;
}

+ (PromptView *)promptViewPrintDirectionWithTitle:(NSString *)title
                            message:(NSString *)message
                         confirmStr:(NSString *)confirmStr
                            confirm:(void (^_Nullable)(NSInteger tag))completeHandler
                          cancelStr:(NSString *)cancelStr
                             cancel:(PromptCancelBlock)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:message preferredStyle:PromptViewStyleCustom];
    
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 115)];
    contentView.backgroundColor = [UIColor clearColor];
    
    UIImageView *transverseImageView = [[UIImageView alloc] init];
    transverseImageView.image = [UIImage imageNamed:@"timetable_transverse"];
    transverseImageView.tag = 1;
    transverseImageView.userInteractionEnabled = YES;
    [contentView addSubview:transverseImageView];
    promptView.transverseImageView = transverseImageView;
    [transverseImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(contentView).offset((111 - 86)/2.0 + 4);
        make.right.mas_equalTo(contentView.mas_centerX).offset(-5);
        make.height.mas_equalTo(86);
        make.width.mas_equalTo(111);
    }];
    UITapGestureRecognizer *transverseImageViewTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:promptView action:@selector(didSelectImageActionEvent:)];
    [promptView.transverseImageView addGestureRecognizer:transverseImageViewTapGesture];
    
    UIImageView *verticalImageView = [[UIImageView alloc] init];
    verticalImageView.image = [UIImage imageNamed:@"timetable_vertical"];
    verticalImageView.tag = 2;
    verticalImageView.userInteractionEnabled = YES;
    [contentView addSubview:verticalImageView];
    promptView.verticalImageView = verticalImageView;
    [verticalImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(contentView).offset(4);
        make.left.mas_equalTo(contentView.mas_centerX).offset((111 - 86) + 5);
        make.width.mas_equalTo(86);
        make.height.mas_equalTo(111);
    }];
    UITapGestureRecognizer *verticalImageViewTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:promptView action:@selector(didSelectImageActionEvent:)];
    [promptView.verticalImageView addGestureRecognizer:verticalImageViewTapGesture];
    
    [promptView addCustomView:contentView];
    
    [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
        if (cancelBlock) {
            cancelBlock();
        }
    }]];
    
    __weak __typeof(&*promptView) weakPromptView = promptView;
    PromptViewAction * confirmAction = [PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (completeHandler) {
            completeHandler(weakPromptView.selectTag);
        }
    }];
    confirmAction.enabled = NO;
    [promptView addAction:confirmAction];
    return promptView;
}

+ (PromptView *)promptViewWithImageURL:(NSString * _Nullable)imageURL
                                 title:(NSString * _Nullable)title
                               message:(NSString * _Nullable)message
                            confirmStr:(NSString * _Nullable)confirmStr
                               confirm:(PromptConfirmBlock _Nullable)confirmBlock
                             cancelStr:(NSString * _Nullable)cancelStr
                                cancel:(PromptCancelBlock _Nullable)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:message imageName:imageURL preferredStyle:PromptViewStyleImageText];
    promptView.bgImageName = @"bgImage_promptView_low";
    [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
        if (cancelBlock) {
            cancelBlock();
        }
    }]];
    PromptViewAction * confirmAction = [PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (confirmBlock) {
            confirmBlock();
        }
    }];
    [promptView addAction:confirmAction];
    return promptView;
}

+ (PromptView *)promptViewWithImageName:(NSString * _Nullable)imageName
                              imageText:(NSString * _Nullable)imageText
                             confirmStr:(NSString * _Nullable)confirmStr
                                confirm:(PromptConfirmBlock _Nullable)confirmBlock
                              cancelStr:(NSString * _Nullable)cancelStr
                                 cancel:(PromptCancelBlock _Nullable)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:nil message:imageText imageName:imageName preferredStyle:PromptViewStyleImageText];
    [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
        if (cancelBlock) {
            cancelBlock();
        }
    }]];
    __weak __typeof(&*promptView) weakPromptView = promptView;
    PromptViewAction * confirmAction = [PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        YYAnimatedImageView * imageView = (YYAnimatedImageView *)weakPromptView.imageView;
        imageView.image = nil;
        imageView.image = [YYImage imageNamed:imageName];
        if (confirmBlock) {
            confirmBlock();
        }
    }];
    confirmAction.tapHide = NO;
    [promptView addAction:confirmAction];
    return promptView;
}

///选择弹窗，无message
+ (PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                                 dataSource:(NSArray * _Nonnull)dataSource
                         selectedDataSource:(NSArray * _Nullable)selectedDataSource
                         isMultipleSelected:(BOOL)isMultipleSelected
                            addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(NSArray * _Nullable selecteds, BOOL isChecked))completeHandler
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock {
    return [PromptView promptViewWithTitle:title message:nil dataSource:dataSource selectedDataSource:selectedDataSource isMultipleSelected:isMultipleSelected addSelectButton:configurationHandler confirmStr:confirmStr confirm:completeHandler cancelStr:cancelStr cancel:cancelBlock];
}

///选择弹窗，有message
+ (PromptView *)promptViewWithTitle:(NSString *)title
                            message:(NSString * _Nullable)message
                         dataSource:(NSArray *)dataSource
                 selectedDataSource:(NSArray *)selectedDataSource
                 isMultipleSelected:(BOOL)isMultipleSelected
                    addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                         confirmStr:(NSString *)confirmStr
                            confirm:(void (^_Nullable)(NSArray * _Nullable selecteds, BOOL isChecked))completeHandler
                          cancelStr:(NSString *)cancelStr
                             cancel:(PromptCancelBlock)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:message preferredStyle:PromptViewStyleMultipleChoice];
    promptView.isMultipleSelect = isMultipleSelected;
    promptView.selectedDataSource = selectedDataSource;
    promptView.dataSource = dataSource;
    if (configurationHandler) {
        [promptView addSelectButtonWithConfigurationHandler:^(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel) {
            configurationHandler(selectButton, selectLabel);
        }];
    }
    if (![CommonUtils isEmptyString:cancelStr]) {
        [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
            if (cancelBlock) {
                cancelBlock();
            }
        }]];
    }
    __weak __typeof(&*promptView) weakPromptView = promptView;
    PromptViewAction * confirmAction = [PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (weakPromptView.selectedDataSource.count == 0) {
            ShowToast(@"请至少选择一个");
            return;
        }
        if (completeHandler) {
            completeHandler(weakPromptView.selectedDataSource, weakPromptView.selectButton.isSelected);
        }
    }];
    [promptView addAction:confirmAction];
    return promptView;
}

///选择弹窗
+ (nonnull PromptView *)subPromptViewWithTitle:(NSString * _Nullable)title
                                 dataSource:(NSArray * _Nonnull)dataSource
                         selectedDataSource:(NSArray * _Nullable)selectedDataSource
                         isMultipleSelected:(BOOL)isMultipleSelected
                            addSelectButton:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(NSArray * _Nullable selecteds, BOOL isChecked))completeHandler
                                  cancelStr:(NSString * _Nullable)cancelStr
                                        cancel:(PromptCancelBlock _Nullable)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:nil preferredStyle:PromptViewStyleMultipleChoice];
    promptView.isMultipleSelect = isMultipleSelected;
    promptView.selectedDataSource = selectedDataSource;
    promptView.dataSource = dataSource;
    promptView.tapBackgroundHide = YES;
    if (configurationHandler) {
        [promptView addSelectButtonWithConfigurationHandler:^(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel) {
            configurationHandler(selectButton, selectLabel);
        }];
    }
    if (![CommonUtils isEmptyString:cancelStr]) {
        [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
            if (cancelBlock) {
                cancelBlock();
            }
        }]];
    }
    __weak __typeof(&*promptView) weakPromptView = promptView;
    PromptViewAction * confirmAction = [PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        [weakPromptView dimiss];
        if (completeHandler) {
            completeHandler(weakPromptView.selectedDataSource, weakPromptView.selectButton.isSelected);
        }
    }];
    [promptView addAction:confirmAction];
    return promptView;
}
+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  otherStr:(NSString * _Nullable)otherStr
                                     other:(PromptConfirmBlock _Nullable)otherBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:nil preferredStyle:PromptViewStylePlainText];
    [promptView addAction:[PromptViewAction actionWithTitle:otherStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (otherBlock) {
            otherBlock();
        }
    }]];
    [promptView addAction:[PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (confirmBlock) {
            confirmBlock();
        }
    }]];
    return promptView;
}

+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock {
    return [PromptView promptViewWithTitle:title confirmStr:confirmStr confirm:confirmBlock cancelStr:nil cancel:nil];
}

+ (nonnull PromptView *)promptViewWithTitle:(id _Nullable)title
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(PromptConfirmBlock _Nullable)confirmBlock
                                  cancelStr:(NSString * _Nullable)cancelStr
                                     cancel:(PromptCancelBlock _Nullable)cancelBlock {
    return [PromptView promptViewWithTitle:title message:nil confirmStr:confirmStr confirm:confirmBlock cancelStr:cancelStr cancel:cancelBlock];
}

+ (PromptView *)promptViewWithTitle:(id)title
                            message:(id)message
                         confirmStr:(NSString *)confirmStr
                            confirm:(PromptConfirmBlock)confirmBlock
                          cancelStr:(NSString *)cancelStr
                             cancel:(PromptCancelBlock)cancelBlock {
    return [PromptView promptViewWithTitle:title message:message logoImageName:nil hasClose:NO confirmStr:confirmStr confirm:confirmBlock cancelStr:cancelStr cancel:cancelBlock];
}

+ (PromptView *)promptViewWithTitle:(id)title
                            message:(id)message
                           hasClose:(BOOL)hasClose
                         confirmStr:(NSString *)confirmStr
                            confirm:(PromptConfirmBlock)confirmBlock {
    return [PromptView promptViewWithTitle:title message:message hasClose:hasClose confirmStr:confirmStr confirm:confirmBlock cancelStr:nil cancel:nil];
}

+ (PromptView *)promptViewWithTitle:(id)title
                            message:(id)message
                           hasClose:(BOOL)hasClose
                         confirmStr:(NSString *)confirmStr
                            confirm:(PromptConfirmBlock)confirmBlock
                          cancelStr:(NSString *)cancelStr
                             cancel:(PromptCancelBlock)cancelBlock {
    return [PromptView promptViewWithTitle:title message:message logoImageName:nil hasClose:hasClose confirmStr:confirmStr confirm:confirmBlock cancelStr:cancelStr cancel:cancelBlock];
}

+ (PromptView *)promptViewWithTitle:(id)title
                            message:(id)message
                      logoImageName:(NSString *)logoImageName
                         confirmStr:(NSString *)confirmStr
                            confirm:(PromptConfirmBlock)confirmBlock
                          cancelStr:(NSString *)cancelStr
                             cancel:(PromptCancelBlock)cancelBlock {
    return [PromptView promptViewWithTitle:title message:message logoImageName:logoImageName hasClose:NO confirmStr:confirmStr confirm:confirmBlock cancelStr:cancelStr cancel:cancelBlock];
}

+ (PromptView *)promptViewWithTitle:(id)title
                            message:(id)message
                      logoImageName:(NSString *)logoImageName
                           hasClose:(BOOL)hasClose
                         confirmStr:(NSString *)confirmStr
                            confirm:(PromptConfirmBlock)confirmBlock
                          cancelStr:(NSString *)cancelStr
                             cancel:(PromptCancelBlock)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:message preferredStyle:PromptViewStylePlainText];
    promptView.logoImageName = logoImageName;
    promptView.hasClose = hasClose;
    if (![CommonUtils isEmptyString:cancelStr]) {
        [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
            if (cancelBlock) {
                cancelBlock();
            }
        }]];
    }
    [promptView addAction:[PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (confirmBlock) {
            confirmBlock();
        }
    }]];
    return promptView;
}

+ (nonnull PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                                    codeType:(NSUInteger)codeType
                                limitLength:(NSUInteger)limitLength
                                addTextView:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler
                                 confirmStr:(NSString * _Nullable)confirmStr
                                    confirm:(void (^_Nullable)(UIImage * _Nonnull image))completeHandler {
    return [PromptView promptViewWithTitle:title message:nil limitLength:limitLength addTextView:configurationHandler confirmStr:confirmStr confirm:^(NSString * _Nonnull text) {
        UIImage *image = [[UIImage alloc] init];
        if (codeType == 1) {
            if (![CommonUtils isPureNumber:text]) {
                ShowToast(@"请输入阿拉伯数字");
                return;
            }
            image = [CommonUtils createBarCode:text
                                          size:CGSizeMake(200, 100)];
        } else {
            image = [CommonUtils createQRCode:text
                                         size:CGSizeMake(200, 200)];
        }
        if (completeHandler) {
            completeHandler(image);
        }
    }];
}

+ (nonnull PromptView *)promptViewWithTitle:(NSString * _Nullable)title
                            message:(NSString * _Nullable)message
                        limitLength:(NSUInteger)limitLength
                        addTextView:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler
                         confirmStr:(NSString * _Nullable)confirmStr
                            confirm:(void (^_Nullable)(NSString * _Nonnull text))completeHandler {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:message preferredStyle:PromptViewStylePlainText];
    [[UIApplication sharedApplication].keyWindow endEditing:NO];
    [promptView addTextViewWithLimitLength:limitLength configurationHandler:configurationHandler];
    [promptView addCancelAction];
    __weak __typeof(&*promptView) weakPromptView = promptView;
    [promptView addAction:[PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (completeHandler) {
            completeHandler(weakPromptView.textView != nil?weakPromptView.textView.text:@"");
        }
    }]];
    if (limitLength != 0) {
        [weakPromptView textViewDidChange:weakPromptView.textView];
    }
    promptView.tapBackgroundHide = NO;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.33 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [promptView.textView becomeFirstResponder];
    });
    return promptView;
}

+ (PromptView *)promptViewWithTitle:(NSString *)title
                            message:(NSString *)message
                        limitLength:(NSUInteger)limitLength
                       addTextField:(void (^_Nullable)(UITextField * _Nonnull textField))configurationHandler
                         confirmStr:(NSString *)confirmStr
                            confirm:(void (^_Nullable)(NSString * _Nonnull text))completeHandler {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:message preferredStyle:PromptViewStylePlainText];
    [promptView addTextFieldWithLimitLength:limitLength configurationHandler:configurationHandler];
    [promptView addCancelAction];
    __weak __typeof(&*promptView) weakPromptView = promptView;
    PromptViewAction * confirmAction = [PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (completeHandler) {
            UITextField * textField = weakPromptView.addTextFields.count > 0?weakPromptView.addTextFields.firstObject:nil;
            NSString * text = textField != nil?textField.text:@"";
            completeHandler(text);
        }
    }];
    [promptView addAction:confirmAction];
    if (limitLength != 0) {
        UITextField * field = nil;
        if (weakPromptView.addTextFields.count > 0) {
            field = weakPromptView.addTextFields.firstObject;
            [weakPromptView textFieldTextChange:field];
        }
    }
    promptView.tapBackgroundHide = NO;
    return promptView;
}

+ (PromptView *)promptViewWithTitle:(id)title
                            message:(id)message
                        bgImageName:(NSString *)imageName
                         confirmStr:(NSString *)confirmStr
                            confirm:(PromptConfirmBlock)confirmBlock
                          cancelStr:(NSString *)cancelStr
                             cancel:(PromptCancelBlock)cancelBlock {
    PromptView * promptView = [[PromptView alloc] initWithTitle:title message:message preferredStyle:PromptViewStylePlainText];
    promptView.tapBackgroundHide = NO;
    promptView.titleLabelHasClickableText = YES;
    promptView.titleLabel.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(15)];
    CGFloat textLeftRightSpace = FIT_LENGTH_PT(36);
    __weak __typeof(promptView) weakPromptView = promptView;
    [promptView.titleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakPromptView.contentView).offset(textLeftRightSpace);
        make.right.equalTo(weakPromptView.contentView).offset(-textLeftRightSpace);
    }];
    [promptView.messageLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakPromptView.contentView).offset(textLeftRightSpace);
        make.right.equalTo(weakPromptView.contentView).offset(-textLeftRightSpace);
        make.top.mas_equalTo(weakPromptView.titleLabel.mas_bottom).offset(13);
    }];
    promptView.textAlignment = NSTextAlignmentLeft;
    promptView.bgImageName = imageName;
    if (![CommonUtils isEmptyString:cancelStr]) {
        [promptView addAction:[PromptViewAction actionWithTitle:cancelStr style:PromptViewActionStyleCancel handler:^(PromptViewAction * _Nonnull action) {
            if (cancelBlock) {
                cancelBlock();
            } else {
                if (weakPromptView.cancelBlock) {
                    weakPromptView.cancelBlock();
                }
            }
        }]];
    }
    [promptView addAction:[PromptViewAction actionWithTitle:confirmStr style:PromptViewActionStyleDefault handler:^(PromptViewAction * _Nonnull action) {
        if (confirmBlock) {
            confirmBlock();
        }
    }]];
    return promptView;
}

+ (nonnull instancetype)promptViewWithTitle:(NSString *)title
                                    message:(NSString *)message
                             preferredStyle:(PromptViewStyle)preferredStyle {
    return [[PromptView alloc] initWithTitle:title message:message preferredStyle:preferredStyle];
}

+ (nonnull instancetype)promptViewWithAttrTitle:(NSAttributedString *)title
                                        message:(NSAttributedString *)message
                                 preferredStyle:(PromptViewStyle)preferredStyle {
    return [[PromptView alloc] initWithTitle:title message:message preferredStyle:preferredStyle];
}

- (nonnull instancetype)initWithTitle:(id)title
                              message:(id)message
                       preferredStyle:(PromptViewStyle)preferredStyle {
    return [self initWithTitle:title message:message imageName:nil preferredStyle:preferredStyle];
}

- (nonnull instancetype)initWithTitle:(id)title
                              message:(id)message
                            imageName:(NSString *)imageName
                       preferredStyle:(PromptViewStyle)preferredStyle {
    self = [super initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    if (self) {
        ///dissmiss监听
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dimiss) name:DissmissPromptViewNotificationKey object:nil];
        
        self.backgroundColor = [UIColor clearColor];
        self.style = preferredStyle;
        self.maxLength = ULONG_MAX;
        self.titleLabelHasClickableText = NO;
        self.tapBackgroundHide = YES;
        self.isFilterWihtespace = YES;
        self.isAllowInputWihtespace = YES;
        self.spacingBetweenCell = 0;
        
        CGFloat contentWidth = FIT_LENGTH_PT(305);
        self.contentHeight = TopSpace + BottomSpace;
        CGFloat contentHeight = 0;
        
        WS(weakSelf);
        
        UIView *contentView = [[UIView alloc] init];
//        [self.contentView addGestureRecognizer:tap];
        contentView.backgroundColor = [UIColor whiteColor];
        contentView.layer.cornerRadius = FIT_LENGTH_PT(15);
        [self addSubview:contentView];
        self.contentView = contentView;
        [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(contentWidth);
            make.height.mas_equalTo(self.contentHeight);
            make.center.equalTo(weakSelf).offset(0);
        }];
        
        switch (preferredStyle) {
            case PromptViewStylePlainText:
            case PromptViewStyleMultipleChoice:
            case PromptViewStyleCustom:
            {
                [self addTitleLabelWithTitle:title];
                
                [self addMessageLabelWithMessage:message];
                
                if (preferredStyle == PromptViewStyleMultipleChoice) {
                    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
                    tableView.bounces = NO;
                    tableView.backgroundColor = KProjectFAFAFBGrayBackGroundColor;
                    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
                    tableView.delegate = self;
                    tableView.dataSource = self;
                    tableView.rowHeight = 42;
                    tableView.tableFooterView = [[UIView alloc] init];
                    tableView.estimatedSectionHeaderHeight = 0;
                    tableView.estimatedSectionFooterHeight = 0;
                    tableView.layer.cornerRadius = FIT_LENGTH_PT(8);
                    tableView.layer.masksToBounds = YES;
                    self.tableView = tableView;
                    if (@available(iOS 15.0, *)) {
                        tableView.sectionHeaderTopPadding = 0;
                    }
                    [self.contentView addSubview:tableView];
                    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                        make.left.equalTo(weakSelf.contentView).offset(FIT_LENGTH_PT(20));
                        make.right.equalTo(weakSelf.contentView).offset(-FIT_LENGTH_PT(20));
                        if (![CommonUtils isNullObject:weakSelf.messageLabel]) {
                            make.top.equalTo(weakSelf.messageLabel.mas_bottom).offset(MiddleSpace);
                        } else if (![CommonUtils isNullObject:weakSelf.titleLabel]) {
                            make.top.equalTo(weakSelf.titleLabel.mas_bottom).offset(MiddleSpace);
                        } else {
                            make.top.equalTo(weakSelf.contentView).offset(TopSpace);
                        }
                        make.height.mas_equalTo(42);
                    }];
                }
            }
                break;
            case PromptViewStylePureImage:
            {
                self.imageUrl = imageName;
                UIImageView *imageView = [[UIImageView alloc] init];
                [imageView sd_setImageWithURL:[NSURL URLWithString:imageName] placeholderImage:[UIImage imageNamed:@"common_placeholder_vertical"] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
                    weakSelf.contentView.backgroundColor = [UIColor clearColor];
                }];
                imageView.userInteractionEnabled = YES;
                contentHeight = FIT_LENGTH_PT(409) - TopSpace - BottomSpace;
                [contentView addSubview:imageView];
                self.imageView = imageView;
                [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.equalTo(weakSelf.contentView);
                    make.centerX.equalTo(weakSelf.contentView);
                    make.width.mas_equalTo(contentWidth);
                    make.height.mas_equalTo(FIT_LENGTH_PT(409));
                }];
                
                UIButton * closeButton = [[UIButton alloc] init];
                [closeButton setImage:[UIImage imageNamed:@"common_close"] forState:UIControlStateNormal];
                [closeButton addTarget:self action:@selector(dimiss) forControlEvents:UIControlEventTouchUpInside];
                [self addSubview:closeButton];
                WS(weakSelf);
                [closeButton mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.right.equalTo(weakSelf.contentView);
                    make.bottom.equalTo(weakSelf.contentView.mas_top).offset(-12);
                    make.width.mas_equalTo(28);
                    make.height.mas_equalTo(28);
                }];
                CGFloat noRemindWidth = 96;
                CGFloat noRemindHeight = 21;
                UIView * remindView = [[UIView alloc] init];
                remindView.backgroundColor = [UIColor clearColor];
                [self addSubview:remindView];
                [remindView mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerX.mas_equalTo(weakSelf.contentView);
                    make.top.mas_equalTo(weakSelf.contentView.mas_bottom).offset(20);
                    make.width.mas_equalTo(noRemindWidth);
                    make.height.mas_equalTo(noRemindHeight);
                }];
                
                QMUIButton * button = [[QMUIButton alloc] init];
                [button setImage:[UIImage imageNamed:@"common_noRemindAgain"] forState:UIControlStateNormal];
                [button setImage:[UIImage imageNamed:@"common_noRemindAgain_selected"] forState:UIControlStateSelected];
                [button setTitle:@"不再提醒" forState:UIControlStateNormal];
                [button setTitle:@"不再提醒" forState:UIControlStateNormal];
                [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [button setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
                button.titleLabel.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(15)];
                button.imageEdgeInsets = UIEdgeInsetsMake(0, 3, 6, 78);
                button.titleEdgeInsets = UIEdgeInsetsMake(0, -78, 0, 0);
                button.spacingBetweenImageAndTitle = 12;
                [button addTarget:self action:@selector(selectActionEvent:) forControlEvents:UIControlEventTouchUpInside];
                [remindView addSubview:button];
                [button mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.equalTo(remindView).offset(0);
                    make.centerY.equalTo(remindView);
                    make.width.mas_equalTo(noRemindWidth);
                    make.height.mas_equalTo(noRemindHeight);
                }];
            }
                break;
                
            case PromptViewStyleImageText:
            {
                CGFloat imageWidth = FIT_LENGTH_PT(186);
                CGFloat imageHeight = imageWidth / 186.0 * 163.0;
                if ([imageName hasPrefix:@"http://"]||[imageName hasPrefix:@"https://"]) {
                    self.imageView = [[UIImageView alloc] init];
                    [self.imageView sd_setImageWithURL:[NSURL URLWithString:imageName] placeholderImage:[UIImage imageNamed:@"commom_avatar_placeholder"]];
                    imageWidth = FIT_LENGTH_PT(115);
                    imageHeight = imageWidth;
                    self.imageView.layer.cornerRadius = imageWidth / 2.0;
                    self.imageView.layer.masksToBounds = YES;
                } else {
                    self.imageView = [[YYAnimatedImageView alloc] initWithImage:[YYImage imageNamed:imageName]];
                    imageWidth = FIT_LENGTH_PT(186);
                    imageHeight = imageWidth / 186.0 * 163.0;
                }
                self.imageView.userInteractionEnabled = YES;
                [contentView addSubview:self.imageView];
                [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.equalTo(weakSelf.contentView).offset(TopSpace);
                    make.centerX.equalTo(weakSelf.contentView);
                    make.width.mas_equalTo(imageWidth);
                    make.height.mas_equalTo(imageHeight);
                }];
                [self.contentView layoutIfNeeded];
                CGFloat imageViewHeight = imageHeight;
                contentHeight += imageViewHeight;
                
                [self addTitleLabelWithTitle:title];
                
                [self addMessageLabelWithMessage:message];
            }
                break;
                
            default:
                break;
        }
        
        [self updateContentHeight:contentHeight];
    }
    return self;
}

- (void)setTitleLabelHasClickableText:(BOOL)titleLabelHasClickableText {
    _titleLabelHasClickableText = titleLabelHasClickableText;
    if (titleLabelHasClickableText&&![CommonUtils isNullObject:self.titleLabel]) {
        YYLabel *titleLabel = nil;
        titleLabel = [[YYLabel alloc] init];
        titleLabel.userInteractionEnabled = YES;
        titleLabel.font = self.titleLabel.font;
        titleLabel.textColor = self.titleLabel.textColor;
        titleLabel.numberOfLines = 0;
        titleLabel.textAlignment = self.titleLabel.textAlignment;
        titleLabel.attributedText = self.titleLabel.attributedText;
        [self.contentView addSubview:titleLabel];
        WS(weakSelf);
        [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(weakSelf.titleLabel);
            make.right.equalTo(weakSelf.titleLabel);
            make.top.equalTo(weakSelf.titleLabel);
            make.bottom.equalTo(weakSelf.titleLabel);
        }];
        self.titleLabel.hidden = YES;
        self.titleLabel = titleLabel;
    }
}

- (void)addTitleLabelWithTitle:(id)title {
    WS(weakSelf);
    CGFloat textLeftRightSpace = FIT_LENGTH_PT(40);
    UILabel *titleLabel = nil;
    if (![CommonUtils isEmptyString:title]||![CommonUtils isEmptyAttributedString:title]) {
        titleLabel = [[UILabel alloc] init];
        titleLabel.userInteractionEnabled = YES;
        titleLabel.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(16)];
        titleLabel.textColor = kProjectTextColor;
        titleLabel.numberOfLines = 0;
        titleLabel.textAlignment = NSTextAlignmentCenter;
        NSAttributedString * attrText = [title isKindOfClass:[NSString class]]?[self attributedStringWithLabel:titleLabel text:title lineSpacing:5]:title;
        if ([attrText isKindOfClass:[NSMutableAttributedString class]]) {
            NSMutableAttributedString *mAttr = (NSMutableAttributedString *)attrText;
            mAttr.lineSpacing = 5;
        }
        titleLabel.attributedText = attrText;
        [self.contentView addSubview:titleLabel];
        self.titleLabel = titleLabel;
        [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(weakSelf.contentView).offset(textLeftRightSpace);
            make.right.equalTo(weakSelf.contentView).offset(-textLeftRightSpace);
            if (self.style == PromptViewStyleImageText) {
                make.top.equalTo(weakSelf.imageView.mas_bottom).offset(14);
            } else {
                make.top.equalTo(weakSelf.contentView).offset(TopSpace);
            }
        }];
        [self.contentView layoutIfNeeded];
        CGFloat titleTextHeight = titleLabel.size.height;
        CGFloat contentHeight = 0;
        if (self.style == PromptViewStyleImageText) {
            contentHeight += 14;
        }
        contentHeight += titleTextHeight;
        [self updateContentHeight:contentHeight];
    }
}

- (void)addMessageLabelWithMessage:(id)message {
    WS(weakSelf);
    CGFloat textLeftRightSpace = FIT_LENGTH_PT(40);
    if (![CommonUtils isEmptyString:message]||![CommonUtils isEmptyAttributedString:message]) {
        UILabel *messageLabel = [[UILabel alloc] init];
        messageLabel.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(15)];
        messageLabel.textColor = kProjectLightTextColor;
        messageLabel.numberOfLines = 0;
        messageLabel.textAlignment = NSTextAlignmentCenter;
        NSAttributedString * attrText = [message isKindOfClass:[NSString class]]?[self attributedStringWithLabel:messageLabel text:message lineSpacing:5]:message;
        if ([attrText isKindOfClass:[NSMutableAttributedString class]]) {
            NSMutableAttributedString *mAttr = (NSMutableAttributedString *)attrText;
            mAttr.lineSpacing = 5;
        }
        messageLabel.attributedText = attrText;
        [self.contentView addSubview:messageLabel];
        self.messageLabel = messageLabel;
        [messageLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(weakSelf.contentView).offset(textLeftRightSpace);
            make.right.equalTo(weakSelf.contentView).offset(-textLeftRightSpace);
            if ([CommonUtils isNullObject:weakSelf.titleLabel]) {
                if (self.style == PromptViewStyleImageText) {
                    make.top.equalTo(weakSelf.imageView.mas_bottom).offset(8);
                } else {
                    make.top.equalTo(weakSelf.contentView).offset(TopSpace);
                }
            } else {
                make.top.equalTo(weakSelf.titleLabel.mas_bottom).offset(5);
            }
        }];
        [self.contentView layoutIfNeeded];
        CGFloat messageTextHeight = messageLabel.size.height;
        CGFloat contentHeight = 0;
        contentHeight += (messageTextHeight + 5);
        [self updateContentHeight:contentHeight];
    }
}

///更新内容高度
- (void)updateContentHeight:(CGFloat)contentHeight {
    self.contentHeight += contentHeight;
    [self.contentView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(self.contentHeight);
    }];
}

/// 增加一个输入框
- (void)addTextFieldWithConfigurationHandler:(void (^_Nullable)(UITextField * _Nonnull textField))configurationHandler {
    [self addTextFieldWithLimitLength:0 configurationHandler:configurationHandler];
}

/// 增加一个输入框
- (void)addTextFieldWithLimitLength:(NSInteger)length configurationHandler:(void (^_Nullable)(UITextField * _Nonnull textField))configurationHandler {
    
    WS(weakSelf);
    UITextField *textField = [[UITextField alloc] init];
    textField.backgroundColor = [UIColor colorWithHexString:@"#FAFAFB"];
    textField.textColor = kProjectTextColor;
    textField.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(15)];
    textField.layer.borderColor = [UIColor colorWithHexString:@"#E5E5E5"].CGColor;
    textField.layer.borderWidth = 1;
    textField.layer.cornerRadius = 8;
    textField.layer.masksToBounds = YES;
    textField.tintColor = kProjectColorNewGreen;
    textField.delegate = self;
    
    textField.leftViewMode = UITextFieldViewModeAlways;
    UIImageView * clearImageView = [[UIImageView alloc] initWithImage:[[UIImage imageWithColor:textField.backgroundColor] qmui_imageResizedInLimitedSize:CGSizeMake(13, 13)]];
    textField.leftView = clearImageView;
    
    UIButton * clearButton = [UIButton buttonWithType:UIButtonTypeCustom];
    clearButton.frame = CGRectMake(0, 0, 50, 50);
    [clearButton setImage:[UIImage imageNamed:@"common_clear"] forState:UIControlStateNormal];
    clearButton.imageEdgeInsets = UIEdgeInsetsMake(15.5, 18, 15.5, 13);
    [clearButton addTarget:self action:@selector(clearTextFieldText:) forControlEvents:UIControlEventTouchUpInside];
    textField.rightViewMode = UITextFieldViewModeWhileEditing;
    textField.rightView = clearButton;
    
    //    UIImage * clearImage = [[UIImage imageNamed:@"common_clear"] qmui_imageResizedInLimitedSize:CGSizeMake(19, 19)];
//    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
//    textField.qmui_clearButtonImage = clearImage;
    [self.contentView addSubview:textField];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.contentView.mas_left).offset(FIT_LENGTH_PT(20));
        make.right.equalTo(weakSelf.contentView.mas_right).offset(-FIT_LENGTH_PT(20));
        if (self.addTextFields.count > 0) {
            UITextField * lastTextField = self.addTextFields.lastObject;
            make.top.equalTo(lastTextField.mas_bottom).offset(MiddleSpace);
        } else {
            if (![CommonUtils isNullObject:weakSelf.messageLabel]) {
                make.top.equalTo(weakSelf.messageLabel.mas_bottom).offset(MiddleSpace);
            } else if (![CommonUtils isNullObject:weakSelf.titleLabel]) {
                make.top.equalTo(weakSelf.titleLabel.mas_bottom).offset(MiddleSpace);
            } else {
                make.top.equalTo(weakSelf.contentView).offset(TopSpace);
            }
        }
        make.height.mas_equalTo(42);
    }];
    
    CGFloat contentHeight = 0;
    contentHeight += (MiddleSpace + 42);
    
    if (length != 0) {
        if (length > 0) {
            [self addCountLabelWithMaxLength:length inputView:textField];
        }
        
        [textField addTarget:self action:@selector(textFieldTextChange:) forControlEvents:UIControlEventEditingChanged];
        
        contentHeight += (11 + 4);
    }
    
    [self updateContentHeight:contentHeight];
    
    if (self.addTextFields.count == 0) {
        //注册通知,监听键盘弹出事件
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidShow:) name:UIKeyboardDidShowNotification object:nil];
        //注册通知,监听键盘消失事件
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidHidden) name:UIKeyboardDidHideNotification object:nil];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.33 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [textField becomeFirstResponder];
        });
    }
    
    [self.addTextFields addObject:textField];
    textField.tag = self.addTextFields.count;
    clearButton.tag = textField.tag;
    
    if (configurationHandler) {
        configurationHandler(textField);
    }
}

- (void)clearTextFieldText:(UIButton *)button {
    UITextField *textField = [self.addTextFields objectAtIndex:button.tag - 1];
    textField.text = nil;
    [self textFieldTextChange:textField];
}

- (void)addCountLabelWithMaxLength:(NSUInteger)length inputView:(UIView *)inputView {
    self.maxLength = length;
    UILabel *countLabel = [[UILabel alloc] init];
    countLabel.textColor = kProjectLightTextColor;
    countLabel.font = [UIFont systemFontOfSize:8];
    countLabel.text = [NSString stringWithFormat:@"0/%lu",length];
    countLabel.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:countLabel];
    self.countLabel = countLabel;
    [countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(inputView.mas_bottom).offset(4);
        make.right.equalTo(inputView).offset(0);
        make.height.mas_equalTo(11);
    }];
}

/// 增加一个TextView
- (void)addTextViewWithConfigurationHandler:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler {
    [self addTextViewWithLimitLength:0 configurationHandler:configurationHandler];
}

/// 增加一个TextView,限制最大字数
- (void)addTextViewWithLimitLength:(NSInteger)length configurationHandler:(void (^_Nullable)(QMUITextView * _Nonnull textView))configurationHandler {
    ///textView只允许添加一个
    if (self.textView != nil) {
        return;
    }
    
    WS(weakSelf);
    QMUITextView *aTextView = [[QMUITextView alloc] init];
    aTextView.textContainerInset = UIEdgeInsetsMake(FIT_LENGTH_PT(5), FIT_LENGTH_PT(13), FIT_LENGTH_PT(10), FIT_LENGTH_PT(12));
    aTextView.backgroundColor = [UIColor colorWithHexString:@"#FAFAFB"];
    aTextView.textColor = kProjectTextColor;
    aTextView.font = [UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    aTextView.layer.borderColor = [UIColor colorWithHexString:@"#E5E5E5"].CGColor;
    aTextView.layer.borderWidth = 1;
    aTextView.layer.cornerRadius = 8;
    aTextView.layer.masksToBounds = YES;
    aTextView.tintColor = kProjectColorNewGreen;
    aTextView.showsVerticalScrollIndicator = NO;
    aTextView.showsHorizontalScrollIndicator = NO;
    aTextView.editable = YES;
    aTextView.placeholderColor = kProjectLightTextColor;
    [self.contentView addSubview:aTextView];
    self.textView = aTextView;
    [aTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.contentView.mas_left).offset(FIT_LENGTH_PT(20));
        make.right.equalTo(weakSelf.contentView.mas_right).offset(-FIT_LENGTH_PT(20));
        if (![CommonUtils isNullObject:weakSelf.messageLabel]) {
            make.top.equalTo(weakSelf.messageLabel.mas_bottom).offset(MiddleSpace);
        } else if (![CommonUtils isNullObject:weakSelf.titleLabel]) {
            make.top.equalTo(weakSelf.titleLabel.mas_bottom).offset(MiddleSpace);
        } else {
            make.top.equalTo(weakSelf.contentView).offset(TopSpace);
        }
        make.height.mas_equalTo(127);
    }];
    
    CGFloat contentHeight = 0;
    contentHeight += (MiddleSpace + 127);
    
    if (length != 0) {
        if (length > 0) {
            [self addCountLabelWithMaxLength:length inputView:aTextView];
        }
        
        aTextView.delegate = self;
        
        contentHeight += (11 + 4);
    }
    
    [self updateContentHeight:contentHeight];
    
    //注册通知,监听键盘弹出事件
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidShow:) name:UIKeyboardDidShowNotification object:nil];
    //注册通知,监听键盘消失事件
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidHidden) name:UIKeyboardDidHideNotification object:nil];
    
    if (configurationHandler) {
        configurationHandler(aTextView);
    }
}

/// 增加一个SelectButton
- (void)addSelectButtonWithConfigurationHandler:(void (^_Nullable)(UIButton * _Nonnull selectButton, UILabel * _Nonnull selectLabel))configurationHandler {
    WS(weakSelf);
    UIButton * button = [[UIButton alloc] init];
    [button setImage:[UIImage imageNamed:@"common_unselected"] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:@"common_selected"] forState:UIControlStateSelected];
    [button addTarget:self action:@selector(selectActionEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.contentView.mas_left).offset(FIT_LENGTH_PT(20));
        make.bottom.equalTo(weakSelf.contentView).offset(-(BottomSpace+41+27));
        make.width.mas_equalTo(23);
        make.height.mas_equalTo(23);
    }];
    self.selectButton = button;
    
    UILabel * titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(15)];
    titleLabel.textColor = kProjectTextColor;
    titleLabel.text = @"忽略以上提示";
    [self.contentView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(button.mas_right).offset(FIT_LENGTH_PT(12));
        make.right.mas_lessThanOrEqualTo(weakSelf.contentView.mas_right).offset(-FIT_LENGTH_PT(20));
        make.centerY.equalTo(button);
        make.height.mas_equalTo(21);
    }];
    
    CGFloat contentHeight = 0;
    contentHeight += (39 + 23);
    
    [self updateContentHeight:contentHeight];
    
    if (configurationHandler) {
        configurationHandler(button, titleLabel);
    }
}

- (void)addCustomView:(UIView *)view {
    if (self.style != PromptViewStyleCustom) {
        return;
    }
    WS(weakSelf);
    [self.contentView addSubview:view];
    self.customView = view;
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.contentView.mas_left);
        make.right.equalTo(weakSelf.contentView.mas_right);
        if (![CommonUtils isNullObject:weakSelf.messageLabel]) {
            make.top.equalTo(weakSelf.messageLabel.mas_bottom).offset(MiddleSpace);
        } else if (![CommonUtils isNullObject:weakSelf.titleLabel]) {
            make.top.equalTo(weakSelf.titleLabel.mas_bottom).offset(MiddleSpace);
        } else {
            make.top.equalTo(weakSelf.contentView).offset(TopSpace);
        }
        make.height.mas_equalTo(view.size.height);
    }];
    
    CGFloat contentHeight = 0;
    contentHeight += (MiddleSpace + view.size.height);
    
    [self updateContentHeight:contentHeight];
}

- (void)addAction:(PromptViewAction *)action {
    if (self.addActions.count == 2) {
        return;
    }
    if (action.style == PromptViewActionStyleCancel) {
        if ([CommonUtils isEmptyString:action.title]) {
            [self addCancelAction];
            return;
        }
        self.cancelAction = action;
    }
    if (action.style == PromptViewActionStyleDefault) {
        self.confirmAction = action;
    }
    [self.addActions addObject:action];
    [self.contentView addSubview:action.button];
    
    WS(weakSelf);
    CGFloat buttonWidth = FIT_LENGTH_PT(127);
    CGFloat buttonLeft = 0;
    if (self.addActions.count == 1) {
        buttonLeft = (FIT_LENGTH_PT(305) - (self.addActions.count)*FIT_LENGTH_PT(127))/2.0;
        
        [self updateContentHeight:(27 + 41)];
    } else {
        buttonLeft = (FIT_LENGTH_PT(305) - FIT_LENGTH_PT(11) - (self.addActions.count)*FIT_LENGTH_PT(127))/2.0;
        PromptViewAction * firstAction = self.addActions.firstObject;
        UIButton * firstButton = firstAction.button;
        [firstButton mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(weakSelf.contentView.mas_left).offset(buttonLeft);
        }];
        buttonLeft += (buttonWidth + FIT_LENGTH_PT(11)) ;
    }
    
    [action.button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.contentView.mas_left).offset(buttonLeft);
        make.bottom.equalTo(weakSelf.contentView).offset(-BottomSpace);
        make.width.mas_equalTo(buttonWidth);
        make.height.mas_equalTo(41);
    }];
}

- (void)addCancelAction {
    PromptViewAction *action = [PromptViewAction actionWithTitle:@"取消" style:PromptViewActionStyleCancel handler:nil];
    [self addAction:action];
}

- (void)display {
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    self.backgroundColor = RGBA(0, 0, 0, .6);
}

- (void)showWithAnimated:(BOOL)animated {
    if (animated) {
        [UIView animateWithDuration:.25 animations:^{
            [self display];
        }];
    } else {
        [self display];
    }
}

- (void)hideWithAnimated:(BOOL)animated {
    if (self.closeBlock) {
        self.closeBlock();
    }
    if (animated) {
        [UIView animateWithDuration:.25 animations:^{
            self.backgroundColor = RGBA(0, 0, 0, 0);
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    } else {
        self.backgroundColor = RGBA(0, 0, 0, 0);
        [self removeFromSuperview];
    }
}

- (void)show {
    [self showWithAnimated:NO];
}

- (void)dimiss {
    [self hideWithAnimated:NO];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)keyboardDidShow:(NSNotification *)notification {
        //获取键盘高度
    NSValue *keyboardObject = [[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect;
    [keyboardObject getValue:&keyboardRect];
    
    if (self.contentView.bottom <= (keyboardRect.origin.y-10)) {
        return;
    }
        //调整放置有textView的view的位置
        //设置动画
    [UIView beginAnimations:nil context:nil];
        //定义动画时间
    [UIView setAnimationDuration:kAnimationDuration];
        //设置view的frame，往上平移
    self.contentView.bottom = keyboardRect.origin.y-10;
    [UIView commitAnimations];
}

-(void)keyboardDidHidden {
    if (self.contentView.center.y == SCREEN_HEIGHT/2) {
        return;
    }
        //定义动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:kAnimationDuration];
        //设置view的frame，往下平移
    self.contentView.top = SCREEN_HEIGHT / 2-self.contentView.height / 2;
    [UIView commitAnimations];
}

- (void)tapBg:(UITapGestureRecognizer *)tap {
    if (self.tapBgBlock) {
        self.tapBgBlock();
    }
    if (self.tapBackgroundHide) {
        __block BOOL isEditing = NO;///是否有正在编辑的控件
        if (![CommonUtils isNullObject:self.textView]) {
            if (self.textView.isFirstResponder) {
                isEditing = YES;
            }
        } else {
            if (self.addTextFields.count > 0) {
                [self.addTextFields enumerateObjectsUsingBlock:^(UITextField *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if (obj.isFirstResponder) {
                        isEditing = YES;
                        *stop = YES;
                    }
                }];
            }
        }
        if (isEditing) {
            [self endEditing:YES];
        } else {
//            UITouch *touch = [touches.allObjects lastObject];
            CGPoint point = [tap locationInView:self];
            BOOL result = CGRectContainsPoint(self.contentView.frame, point);
            if (!result) {
                [self hideWithAnimated:YES];
            }
        }
    } else {
        [self endEditing:YES];
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches.allObjects lastObject];
    CGPoint point = [touch locationInView:self];
    BOOL result = CGRectContainsPoint(self.contentView.frame, point);
    if (!result) {
        ///点击了背景
        if (self.tapBgBlock) {
            self.tapBgBlock();
        }
    }
    if (self.tapBackgroundHide) {
        __block BOOL isEditing = NO;///是否有正在编辑的控件
        if (![CommonUtils isNullObject:self.textView]) {
            if (self.textView.isFirstResponder) {
                isEditing = YES;
            }
        } else {
            if (self.addTextFields.count > 0) {
                [self.addTextFields enumerateObjectsUsingBlock:^(UITextField *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if (obj.isFirstResponder) {
                        isEditing = YES;
                        *stop = YES;
                    }
                }];
            }
        }
        if (isEditing) {
            [self endEditing:YES];
        } else {
            if (!result) {
                [self hideWithAnimated:YES];
            }
        }
    } else {
        [self endEditing:YES];
    }
}

#pragma mark - Button Action

- (void)segmentButtonClick:(UIButton *)sender {
    if (self.selectedSegment < 0) {
        return;
    }
    for (UIButton *button in self.segmentButtons) {
        button.selected = NO;
        button.layer.borderWidth = 1;
    }
    sender.selected = YES;
    sender.layer.borderWidth = 0;
    self.selectedSegment = sender.tag;
}

///点击图片广告
- (void)didSelectImage:(UITapGestureRecognizer *)sender {
    if (self.didSelectImageBlock) {
        self.didSelectImageBlock(self.imageUrl);
    }
}

- (void)didSelectImageActionEvent:(UITapGestureRecognizer *)sender {
    self.selectTag = sender.view.tag;
    self.confirmAction.enabled = YES;
    if (sender.view == self.verticalImageView) {
        self.verticalImageView.image = [UIImage imageNamed:@"timetable_vertical_selected"];
        self.transverseImageView.image = [UIImage imageNamed:@"timetable_transverse"];
    } else {
        self.verticalImageView.image = [UIImage imageNamed:@"timetable_vertical"];
        self.transverseImageView.image = [UIImage imageNamed:@"timetable_transverse_selected"];
    }
}

- (void)selectActionEvent:(UIButton *)button {
    button.selected = !button.selected;
    if (self.style == PromptViewStylePureImage) {
        if (self.confirmBlock) {
            self.confirmBlock();
        }
        [self hideWithAnimated:YES];
    }
}

- (void)closeButtonAction:(UIButton *)button {
    if (self.closeBlock) {
        _closeBlock();
    }
    [self dimiss];
}

- (void)confirmButtonAction:(PromptButton *)button {
    if (self.confirmBlock) {
        _confirmBlock();
    }
    [self dimiss];
}

- (void)cancelButtonAction:(PromptButton *)button {
    if (self.cancelBlock) {
        _cancelBlock();
    }
    if (self.tableConfirmBlock) {
        self.tableConfirmBlock(self.courseString);
    }
    if (self.transConfirmBlock) {
        self.transConfirmBlock(self.selectTag);
    }
    [self dimiss];
}

- (NSAttributedString *)attributedStringWithLabel:(UILabel * _Nonnull)label text:(NSString * _Nullable)text lineSpacing:(CGFloat)lineSpacing {
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] initWithString:[CommonUtils isEmptyString:text]?([CommonUtils isEmptyString:label.text]?label.text:@""):text];
    attr.font = label.font;
    attr.color = label.textColor;
    attr.lineSpacing = lineSpacing;
    attr.alignment = label.textAlignment;
    return attr;
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return self.spacingBetweenCell > 0 ? ((self.dataSource.count - 1) == section ? CGFLOAT_MIN : self.spacingBetweenCell) : CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return self.spacingBetweenCell > 0 ? 69 : 42;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.spacingBetweenCell > 0 ? self.dataSource.count : 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.spacingBetweenCell > 0 ? 1 : self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *identifier = @"PromptMultipleSelectTableViewCell";
    PromptMultipleSelectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[PromptMultipleSelectTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.nameLabel.text = [self.dataSource objectAtIndex:self.spacingBetweenCell > 0 ? indexPath.section : indexPath.row];
    UIImage * image = [[UIImage imageNamed:[self.selectedDataSource containsObject:indexPath]?(self.isMultipleSelect?@"common_selected":@"common_singleSelected"):@"common_unselected"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    if ([self.selectedDataSource containsObject:indexPath]) {
        image = [UIImage imageNamed:self.isMultipleSelect?@"common_selected":@"common_singleSelected"];
        if (self.themeColor != nil) {
            image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
            cell.selectImageView.tintColor = self.themeColor;
        }
    } else {
        image = [UIImage imageNamed:@"common_unselected"];
    }
    cell.selectImageView.image = image;
    cell.lineView.hidden = self.spacingBetweenCell > 0 ? YES : ((self.dataSource.count - 1) == indexPath.row);
    cell.contentView.layer.cornerRadius = self.spacingBetweenCell > 0 ? FIT_LENGTH_PT(8) : 0;
    cell.contentView.layer.masksToBounds = self.spacingBetweenCell > 0 ? YES : NO;
    cell.contentView.layer.borderColor = self.spacingBetweenCell > 0 ? kProjectLayerE5E5E5BorderColor.CGColor : [UIColor clearColor].CGColor;
    cell.contentView.layer.borderWidth = self.spacingBetweenCell > 0 ? FIT_LENGTH_PT(1) : 0;;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.isMultipleSelect) {
        if ([self.selectedDataSource containsObject:indexPath]) {
            [self.selectedDataSource removeObject:indexPath];
        } else {
            [self.selectedDataSource addObject:indexPath];
        }
        [tableView reloadRowAtIndexPath:indexPath withRowAnimation:UITableViewRowAnimationNone];
    } else {
        NSMutableArray * indexPaths = [NSMutableArray array];
        if (![self.selectedDataSource containsObject:indexPath]) {
            if (self.selectedDataSource.count != 0) {
                [indexPaths addObject:self.selectedDataSource.firstObject];
                [self.selectedDataSource removeAllObjects];
            }
            [self.selectedDataSource addObject:indexPath];
        } else {
            if (self.spacingBetweenCell <= 0) {
                [self.selectedDataSource removeObject:indexPath];
            }
        }
        [indexPaths addObject:indexPath];
        [tableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
    }
    self.confirmAction.tapHide = self.selectedDataSource.count > 0?YES:NO;
}

#pragma mark - UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (self.isAllowInputWihtespace) {
        return YES;
    } else {
        if (([CommonUtils isEmptyBlankSpace:string]||[string isEqualToString:@" "])&&![string isEqualToString:@""]) {
            return NO;
        } else {
            return YES;
        }
    }
}

#pragma mark - UITextViewDelegate,QMUITextViewDelegate

- (void)textViewDidChange:(UITextView *)textView {
    [self limitInputWithInputView:textView];
    if (self.isFilterWihtespace) {
        self.confirmAction.button.enabled = [CommonUtils isEmptyBlankSpace:textView.text] ? NO : YES;
    } else {
        self.confirmAction.button.enabled = textView.text.length == 0 ? NO : YES;
    }
}

#pragma mark - getter and setter

- (void)setTitle:(NSString *)title {
    if (self.titleLabel != nil) {
        self.titleLabel.text = title;
    }
    _title = title;
}

- (void)setTitleColor:(UIColor *)titleColor {
    if (self.titleLabel != nil&&titleColor != nil) {
        self.titleLabel.textColor = titleColor;
    }
    _titleColor = titleColor;
}

- (void)setTitleFont:(UIFont *)titleFont {
    if (self.titleLabel != nil&&titleFont != nil) {
        self.titleLabel.font = titleFont;
    }
    _titleFont = titleFont;
}

- (void)setMessage:(NSString *)message {
    if (self.messageLabel != nil) {
        self.messageLabel.text = message;
    }
    _message = message;
}

- (void)setMessageColor:(UIColor *)messageColor {
    if (self.messageLabel != nil&&messageColor != nil) {
        self.messageLabel.textColor = messageColor;
    }
    _messageColor = messageColor;
}

- (void)setMessageFont:(UIFont *)messageFont {
    if (self.messageLabel != nil&&messageFont != nil) {
        self.messageLabel.font = messageFont;
    }
    _messageFont = messageFont;
}

- (void)setStyle:(PromptViewStyle)style {
    _style = style;
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment {
    _textAlignment = textAlignment;
    if (self.titleLabel != nil) {
        self.titleLabel.textAlignment = textAlignment;
    }
    if (self.messageLabel != nil) {
        self.messageLabel.textAlignment = textAlignment;
    }
}

- (void)setThemeColor:(UIColor *)themeColor {
    _themeColor = themeColor;
    if (self.confirmAction != nil) {
        [self.confirmAction.button setBackgroundImage:[UIImage imageWithColor:themeColor] forState:UIControlStateNormal];
    }
    if (self.tableView != nil&&self.selectedDataSource.count > 0) {
        [self.tableView reloadData];
    }
}

- (void)setTapBackgroundHide:(BOOL)tapBackgroundHide {
    _tapBackgroundHide = tapBackgroundHide;
//    if (tapBackgroundHide) {
//        if (self.gestureRecognizers.count == 0) {
//            UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapBg:)];
//            [self addGestureRecognizer:tap];
//        }
//    } else {
//        if (self.gestureRecognizers.count > 0) {
//            [self.gestureRecognizers enumerateObjectsUsingBlock:^(__kindof UIGestureRecognizer * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//                [self removeGestureRecognizer:obj];
//            }];
//        }
//    }
}

- (void)setHasLogo:(BOOL)hasLogo {
    _hasLogo = hasLogo;
    if (hasLogo) {
        self.logoImageName = @"logo_promptView";
    }
}

- (void)setLogoImageName:(NSString *)logoImageName {
    if (![CommonUtils isEmptyString:logoImageName]&&[CommonUtils isEmptyString:self.logoImageName]) {
        _logoImageName = logoImageName;
        UIImageView *logoImageView = [[UIImageView alloc] init];
        UIImage * image = [UIImage imageNamed:logoImageName];
        logoImageView.image = image;
        [self addSubview:logoImageView];
        self.logoImageView = logoImageView;
        WS(weakSelf);
        [logoImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(weakSelf.contentView);
            make.bottom.equalTo(weakSelf.contentView.mas_top).offset(16);
            make.width.mas_equalTo(image.size.width);
            make.height.mas_equalTo(image.size.height);
        }];
    }
}

- (void)setLogoBottom:(CGFloat)logoBottom {
    if (self.logoImageView != nil) {
        WS(weakSelf);
        [self.logoImageView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(weakSelf.contentView.mas_top).offset(logoBottom);
        }];
    }
}

- (void)setHasClose:(BOOL)hasClose {
    _hasClose = hasClose;
    if (hasClose) {
        UIButton * closeButton = [[UIButton alloc] init];
        [closeButton setImage:[UIImage imageNamed:@"comment_close_circular"] forState:UIControlStateNormal];
        CGFloat inset = FIT_LENGTH_PT(12);
        CGFloat buttonWidth = inset*2 + FIT_LENGTH_PT(19);
        closeButton.imageEdgeInsets = UIEdgeInsetsMake(inset, inset, inset, inset);
        [closeButton addTarget:self action:@selector(dimiss) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:closeButton];
        WS(weakSelf);
        [closeButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(weakSelf.contentView);
            make.top.equalTo(weakSelf.contentView);
            make.width.mas_equalTo(buttonWidth);
            make.height.mas_equalTo(buttonWidth);
        }];
    }
}

- (void)setBgImageName:(NSString *)bgImageName {
    _bgImageName = bgImageName;
    if (![CommonUtils isEmptyString:bgImageName]&&self.bgImageView == nil) {
        UIImageView *bgImageView = [[UIImageView alloc] init];
        bgImageView.userInteractionEnabled = YES;
        bgImageView.image = [UIImage imageNamed:bgImageName];
        [self.contentView addSubview:bgImageView];
        self.bgImageView = bgImageView;
        [self.contentView sendSubviewToBack:bgImageView];
        WS(weakSelf);
        [bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(weakSelf.contentView);
            make.bottom.equalTo(weakSelf.contentView);
            make.left.equalTo(weakSelf.contentView);
            make.right.equalTo(weakSelf.contentView);
        }];
    }
}

- (void)setDataSource:(NSArray *)dataSource {
    _dataSource = dataSource;
    CGFloat tableHeight = dataSource.count > 6?(6*42):(dataSource.count*42);
    [self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(tableHeight);
    }];
    [self.tableView reloadData];
    
    CGFloat contentHeight = 0;
    contentHeight += (MiddleSpace + tableHeight);
    
    [self updateContentHeight:contentHeight];
}

- (void)setSelectedDataSource:(NSMutableArray *)selectedDataSource {
    NSMutableArray * mArr = [NSMutableArray array];
    if (selectedDataSource.count > 0) {
        id first = selectedDataSource.firstObject;
        if ([first isKindOfClass:[NSIndexPath class]]) {
            if (self.isMultipleSelect) {
                [mArr addObjectsFromArray:selectedDataSource];
            } else {
                [mArr addObject:first];
            }
        } else if ([first isKindOfClass:[NSNumber class]]) {
            [selectedDataSource enumerateObjectsUsingBlock:^(NSNumber *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [mArr addObject:[NSIndexPath indexPathForRow:self.spacingBetweenCell > 0 ? 0 : obj.integerValue inSection:self.spacingBetweenCell > 0 ? obj.integerValue : 0]];
                if (!self.isMultipleSelect&&idx == 0) {
                    *stop = YES;
                }
            }];
        } else if ([first isKindOfClass:[NSString class]]) {
            [selectedDataSource enumerateObjectsUsingBlock:^(NSString *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSInteger index = [selectedDataSource indexOfObject:obj];
                [mArr addObject:[NSIndexPath indexPathForRow:self.spacingBetweenCell > 0 ? 0 : index inSection:self.spacingBetweenCell > 0 ? index : 0]];
                if (!self.isMultipleSelect&&idx == 0) {
                    *stop = YES;
                }
            }];
        }
    }
    _selectedDataSource = mArr;
}

- (void)setSpacingBetweenCell:(NSUInteger)spacingBetweenCell {
    _spacingBetweenCell = spacingBetweenCell;
    //刷新selectedDataSource
    if (self.selectedDataSource.count > 0) {
        NSMutableArray * mArr = [NSMutableArray array];
        [self.selectedDataSource enumerateObjectsUsingBlock:^(NSIndexPath *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [mArr addObject:@(obj.row)];
        }];
        self.selectedDataSource = mArr;
    }
    
    self.tableView.backgroundColor = spacingBetweenCell > 0 ? [UIColor whiteColor] : KProjectFAFAFBGrayBackGroundColor;
    
    CGFloat tableHeight = self.dataSource.count > 4?(4*69 + 3*spacingBetweenCell):(self.dataSource.count*69 + (self.dataSource.count-1)*spacingBetweenCell);
    tableHeight+= MiddleSpace;
    
    [self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(tableHeight);
    }];
    [self.tableView reloadData];
    ///没有cell间距（cell间距为0）的tableView的原先高度
    CGFloat oldTableHeight = self.dataSource.count > 6?(6*42):(self.dataSource.count*42);
    CGFloat contentHeight = 0;
    contentHeight += (tableHeight - MiddleSpace - oldTableHeight);///内容高度更新时，减去原先高度
    
    [self updateContentHeight:contentHeight];
}

- (NSArray<UITextField *> *)textFields {
    return [NSArray arrayWithArray:self.addTextFields];
}

- (NSMutableArray *)addTextFields {
    if (_addTextFields == nil) {
        _addTextFields = [NSMutableArray array];
    }
    return _addTextFields;
}

- (NSMutableArray<PromptViewAction *> *)addActions {
    if (_addActions == nil) {
        _addActions = [NSMutableArray array];
    }
    return _addActions;
}

- (NSMutableArray *)selectedDataSource {
    if (_selectedDataSource == nil) {
        _selectedDataSource = [NSMutableArray array];
    }
    return _selectedDataSource;
}

- (NSMutableArray *)segmentButtons {
    if (_segmentButtons == nil) {
        _segmentButtons = [NSMutableArray array];
    }
    return _segmentButtons;
}

@end

@interface PromptViewAction ()
@property(nonatomic, copy, readwrite) NSString *title;
@property(nonatomic, assign, readwrite) PromptViewActionStyle style;
@property(nonatomic, copy) void (^handler)(PromptViewAction * _Nonnull action);
@end

@implementation PromptViewAction

+ (instancetype)actionWithTitle:(NSString *)title style:(PromptViewActionStyle)style handler:(void (^)(PromptViewAction * _Nonnull))handler {
    PromptViewAction *action = [[self alloc] init];
    action.title = title;
    action.style = style;
    action.handler = handler;
    return action;
}

- (nonnull instancetype)init {
    self = [super init];
    if (self) {
        self.tapHide = YES;
        _button = [[UIButton alloc] init];
        [self.button setBackgroundImage:[UIImage imageWithColor:KProjectF6F8F9GrayBackGroundColor] forState:UIControlStateDisabled];
        [self.button setTitleColor:kProjectLightTextColor forState:UIControlStateDisabled];
        self.button.titleLabel.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(17)];
        self.button.layer.cornerRadius = 41/2.0;
        self.button.layer.masksToBounds = YES;
        [self.button addTarget:self action:@selector(handleAlertActionEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)handleAlertActionEvent:(id)sender {
    if (self.isTapHide) {
        [[NSNotificationCenter defaultCenter] postNotificationName:DissmissPromptViewNotificationKey object:nil];
    }
    if (self.handler) {
        self.handler(self);
    }
}

- (void)setTitle:(NSString *)title {
    _title = title;
    [self.button setTitle:title forState:UIControlStateNormal];
}

- (void)setStyle:(PromptViewActionStyle)style {
    _style = style;
    if (style == PromptViewActionStyleDefault) {
        [self.button setBackgroundImage:[UIImage imageWithColor:kProjectColorNewGreen] forState:UIControlStateNormal];
        [self.button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    } else if (style == PromptViewActionStyleCancel) {
        [self.button setBackgroundImage:[UIImage imageWithColor:KProjectF6F8F9GrayBackGroundColor] forState:UIControlStateNormal];
        [self.button setTitleColor:kProjectLightTextColor forState:UIControlStateNormal];
    } else {
        [self.button setBackgroundImage:[UIImage imageWithColor:kProjectButtonRedColor] forState:UIControlStateNormal];
        [self.button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
}

- (void)setEnabled:(BOOL)enabled {
    self.button.enabled = enabled;
}

- (void)setTapHide:(BOOL)tapHide {
    _tapHide = tapHide;
}

@end
