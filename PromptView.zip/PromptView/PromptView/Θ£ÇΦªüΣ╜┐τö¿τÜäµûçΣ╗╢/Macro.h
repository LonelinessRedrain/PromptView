//
//  Macro.h
//  StudyAbroad
//
//  Created by tqnd on 14-8-5.
//  Copyright (c) 2014年 tqnd. All rights reserved.
//

#ifndef StudyAbroad_Macro_h
#define StudyAbroad_Macro_h

#define CONNECT_URL @"http://www.bjyongjie.com/phone/index.php/Index"
#define MEMOBIRD_APPSTORE_URL @"https://apps.apple.com/cn/app/id1441413158"

#define kAccessKeyId @"nJvuijsfytjNQgAC"
#define kAccessKeySecret @"La8uct461AA3iD4Pdxjz6A99M4vP3G"

//#define CONNECT_URL @"http://121.40.91.37/phone/index.php/Index"

static const NSInteger XGSMaxAppleTag = 101; // 0-100的tag值为apple官方占用

#define USER_ID  @"userId"
#define USER_Name  @"userName"
#define USER_Info   @"userInfo"
#define NETWORK_ERROR  @"当前网络不给力"

#define HTTP_TYPE @"POST"

// Debug

#ifdef DEBUG
#   define DLog(fmt, ...) NSLog((@"%s[%d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#   define ALog(fmt, ...) NSLog((@"%s[%d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#   define DLog(...)
#   define ALog(...)
#endif

#pragma mark - NSLog
#ifdef DEBUG
#define NSLog(FORMAT, ...) fprintf(stderr,"%s:%d\t%s\n",[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String], __LINE__,   [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String])
#else
#define NSLog(FORMAT, ...) nil
#endif

// Common

#define FORMAT(string, args...) [NSString stringWithFormat:string, args]

#define INTERFACE_IS_PAD     ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
#define INTERFACE_IS_PHONE   ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)

#define IS_IPHONE           [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone
#define iPhone5             ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define IS_IPHONE_6         ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750,1334), [[UIScreen mainScreen] currentMode].size) : NO)
#define IS_IPHONE_6_PLUS    ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242,2208), [[UIScreen mainScreen] currentMode].size) : NO)
#define IS_IPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)
//#define IS_IPHONE_Xr ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) : NO)

//#define IS_IPhoneX_Series (([[UIScreen mainScreen] currentMode].size.height / [[UIScreen mainScreen] currentMode].size.width) > 2)
#define IS_IPhoneX_Series ({\
BOOL isPhoneX = NO;\
if (@available(iOS 11.0, *)) {\
    isPhoneX = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom > 0.0;\
}\
isPhoneX;\
})

#define JSON_EXCLUDE_NULL(x)        [[x stringByReplacingOccurrencesOfString : @":null" withString : @":\"\""] stringByReplacingOccurrencesOfString : @":NaN" withString : @":\"0\""]



#pragma mark --screen //屏幕大小

#define SCREEN_BOUNDS [UIScreen mainScreen].bounds
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define SCREEN_STATUSBARHEIGHET (IS_IPhoneX_Series ? 44 : 20)
#define SCREEN_NAVIGATIONBARHEIGHT 44
#define SCREEN_HOMEINDICATORHEIGHT (IS_IPhoneX_Series ? 34 : 0)
#define XGSDefaultNavigationItemFont [UIFont systemFontOfSize:18]

// String

#define STR_FROM_INT(__X__) [NSString stringWithFormat:@"%d", __X__]


// UserDefaults

#define PROPERTY_OBJECT_USER_DEFAULT(accessor, mutator, key) \
USER_DEFAULT_ACCESSOR (accessor, key) \
USER_DEFAULT_MUTATOR (mutator, key)

#define USER_DEFAULTS [NSUserDefaults standardUserDefaults]

#define USER_DEFAULT_ACCESSOR(accessor, key) \
- (id)accessor { \
return [[NSUserDefaults standardUserDefaults] objectForKey:key];  \
}

#define USER_DEFAULT_MUTATOR(mutator, key) \
- (void)mutator:(id)value { \
[[NSUserDefaults standardUserDefaults] setObject:value forKey:key]; \
[[NSUserDefaults standardUserDefaults] synchronize];    \
}

// UserDefaults C type

#define PROPERTY_BOOL_USER_DEFAULT(accessor, mutator, key) \
USER_DEFAULT_MUTATOR_CTYPE (mutator, key, BOOL) \
- (BOOL)accessor {return [[[NSUserDefaults standardUserDefaults] objectForKey:key] boolValue];}

#define PROPERTY_INT_USER_DEFAULT(accessor, mutator, key) \
USER_DEFAULT_MUTATOR_CTYPE (mutator, key, int) \
- (int)accessor {return [[[NSUserDefaults standardUserDefaults] objectForKey:key] intValue];}

#define PROPERTY_FLOAT_USER_DEFAULT(accessor, mutator, key) \
USER_DEFAULT_MUTATOR_CTYPE (mutator, key, float) \
- (float)accessor {return [[[NSUserDefaults standardUserDefaults] objectForKey:key] floatValue];}

#define USER_DEFAULT_MUTATOR_CTYPE(mutator, key, type) \
- (void)mutator:(type)value { \
[[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key]; \
[[NSUserDefaults standardUserDefaults] synchronize];    \
}

#pragma mark 模拟器判断

#if TARGET_IPHONE_SIMULATOR
#define IS_SIMULATOR 1
#elif TARGET_OS_IPHONE
#define IS_SIMULATOR 0
#endif


// Delegate

#define DELEGATE_CALLBACK(DELEGATE, SEL) if (DELEGATE && [DELEGATE respondsToSelector:@selector(SEL)]) [DELEGATE performSelector:@selector(SEL)]

#define DELEGATE_CALLBACK_ONE_PARAMETER(DELEGATE, SEL, X) if (DELEGATE && [DELEGATE respondsToSelector:@selector(SEL)]) [DELEGATE performSelector:@selector(SEL) withObject:X]

#define DELEGATE_CALLBACK_TWO_PARAMETER(DELEGATE, SEL, X, Y) if (DELEGATE && [DELEGATE respondsToSelector:@selector(SEL)]) [DELEGATE performSelector:@selector(SEL) withObject:X withObject:Y]

#define DELEGATE_CALLBACK_ARRAY(__delegate__, __SEL__, __array__) \
if (__delegate__ && [__delegate__ respondsToSelector:@selector(__SEL__)]) { \
[[NSInvocation invocationWithTarget:__delegate__ selector:@selector(__SEL__) argumentArray:(__array__)] invoke]; \
}

#define DELEGATE_CALLBACK_PARAMETERS(__delegate__, __SEL__, args...) \
if (__delegate__ && [__delegate__ respondsToSelector:@selector(__SEL__)]) { \
NSInvocation *invocation = [NSInvocation invocationWithTarget:delegate selector:@selector(__SEL__) arguments:args]; \
[invocation invoke]; \
}

#define DELEGATE_DELAY_CALLBACK_PARAMETERS(__delegate__, __DELAY__, __SEL__, args...) \
if (__delegate__ && [__delegate__ respondsToSelector:@selector(__SEL__)]) { \
NSInvocation *invocation = [NSInvocation invocationWithTarget:delegate selector:@selector(__SEL__) arguments:args]; \
[invocation performSelector:@selector(invoke) withObject:nil afterDelay:__DELAY__];\
}

// System


#define IOS_OR_LATER(a)	([[UIDevice currentDevice].systemVersion doubleValue] >= a)


// Safe releases

#define RELEASE_SAFELY(__POINTER) { [__POINTER release]; __POINTER = nil; }
#define INVALIDATE_TIMER(__TIMER) {if([__TIMER isValid]) {[__TIMER invalidate]; __TIMER = nil;} }


// UIColor
#define RGB(R,G,B)		[UIColor colorWithRed:R/255.0f green:G/255.0f blue:B/255.0f alpha:1.0f]
#define RGBA(R,G,B,A)	[UIColor colorWithRed:R/255.0f green:G/255.0f blue:B/255.0f alpha:A]

#define HexColor(string)        [UIColor colorWithHexString:string]

#define RGB_HEX(V)		[UIColor colorWithHexValue:V]

#define RGBA_HEX(V, A)	[UIColor colorWithHexValue:V alpha:A]

#define RGB_SHORT(V)	[UIColor colorWithShortHexValue:V]

// UIView

#define UIViewAutoresizingFlexibleWidthAndHeight UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight

#define FIT_LENGTH_PX(length) ((length) / 1080.0 * SCREEN_WIDTH) // 弃用
#define FIT_LENGTH_PT(length) (length / 414.0 * SCREEN_WIDTH)
#define FONTSIZE_PX(size) (size * 0.375) //px字号转pt字号


// UIText

#ifdef __IPHONE_6_0

#define UILineBreakModeWordWrap			NSLineBreakByWordWrapping
#define UILineBreakModeCharacterWrap	NSLineBreakByCharWrapping
#define UILineBreakModeClip				NSLineBreakByClipping
#define UILineBreakModeHeadTruncation	NSLineBreakByTruncatingHead
#define UILineBreakModeTailTruncation	NSLineBreakByTruncatingTail
#define UILineBreakModeMiddleTruncation	NSLineBreakByTruncatingMiddle

#define UITextAlignmentLeft				NSTextAlignmentLeft
#define UITextAlignmentCenter			NSTextAlignmentCenter
#define UITextAlignmentRight			NSTextAlignmentRight


#endif	// #ifdef __IPHONE_6_0



// ARC

#if defined(__has_feature) && __has_feature(objc_arc_weak)
#define BD_WEAK weak
#define BD_STRONG strong

#elif defined(__has_feature)  && __has_feature(objc_arc)
#define BD_WEAK unsafe_unretained
#define BD_STRONG retain

#else

#define BD_WEAK assign
#define BD_STRONG retain

#endif

#endif

#if __has_feature(objc_arc)
#define J_PROP_RETAIN strong
#define J_RETAIN(x) (x)
#define J_RELEASE(x)
#define J_AUTORELEASE(x) (x)
#define J_BLOCK_COPY(x) (x)
#define J_BLOCK_RELEASE(x)
#define J_SUPER_DEALLOC()
#define J_AUTORELEASE_POOL_START() @autoreleasepool {
#define J_AUTORELEASE_POOL_END() }
#else
#define J_PROP_RETAIN retain
#define J_RETAIN(x) ([(x) retain])
#define J_RELEASE(x) ([(x) release])
#define J_AUTORELEASE(x) ([(x) autorelease])
#define J_BLOCK_COPY(x) (Block_copy(x))
#define J_BLOCK_RELEASE(x) (Block_release(x))
#define J_SUPER_DEALLOC() ([super dealloc])
#define J_AUTORELEASE_POOL_START() NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
#define J_AUTORELEASE_POOL_END() [pool release];
#endif

#define FONTFIT (SCREEN_WIDTH - 60) / 315
#define kSeparateLineColor [UIColor colorWithHexString:@"#e1e1e1"]
#define kDefaultTextColor [UIColor colorWithHexString:@"#3d4245"]
#define kGrayColor RGB(242, 242, 242)

#pragma mark --图片类型
typedef NS_ENUM(NSInteger, pictureType) {
    pictureType_custom = 0,     //默认，相册或拍照
    pictureType_draw ,   //涂鸦板
    pictureType_textBoard,  //写字板
    pictureType_import,     //英文重要信息的标识
    pictureType_template,     //模板
    pictureType_todolist,     //列表
    pictureType_voice,        //语音纸条
    pictureType_editor1_4,    //新编辑器编辑的图片
    pictureType_afanti,       //搜题的图片
    pictureType_banner,       //横幅的图片
};


#pragma mark - 文件系统
#define DOCUMENT_DIR [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject]
#define CACHES_DIR [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject]

#pragma mark - NSObject

#warning 以下内容为临时添加，为素材图片选择库工作，后续优化删除

#define WS(weakSelf) __weak __typeof(&*self) weakSelf = self

#define TotaliPhoneX (NAVIGATION_BAR_HEIGHT+HOME_INDICATOR_HEIGHT)

// 判断是否是ipad
#define isPadDevice ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)

#define iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)
// 判断iPHoneXr
#define IS_IPHONE_Xr ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) && !isPadDevice : NO)
// 判断iPhoneXs
#define IS_IPHONE_Xs ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) && !isPadDevice : NO)
// 判断iPhoneXs Max
#define IS_IPHONE_Xs_Max ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) && !isPadDevice : NO)
// 判断iPhone11
#define IS_IPHONE_11 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) && !isPadDevice : NO)

#define IS_IPHONE_11_Pro ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) && !isPadDevice : NO)

#define IS_IPHONE_11_Pro_Max ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) && !isPadDevice : NO)

#define IS_IPHONE_12_Pro ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? (CGSizeEqualToSize(CGSizeMake(1170, 2532), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(1179, 2556), [[UIScreen mainScreen] currentMode].size)) && !isPadDevice : NO)

#define IS_IPHONE_12_Pro_Max ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? (CGSizeEqualToSize(CGSizeMake(1284, 2778), [[UIScreen mainScreen] currentMode].size)||CGSizeEqualToSize(CGSizeMake(1290, 2796), [[UIScreen mainScreen] currentMode].size)) && !isPadDevice : NO)

#define Height_StatusBar ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 44.0 : 20.0)
#define Height_NavBar ([UIApplication sharedApplication].keyWindow.it_navigationHeight)
#define Height_TabBar ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 83.0 : 49.0)

//判断iPhoneX所有系列
#define IS_PhoneXAll (iPhoneX || IS_IPHONE_Xr || IS_IPHONE_Xs_Max || IS_IPHONE_Xs || IS_IPHONE_11 || IS_IPHONE_11_Pro || IS_IPHONE_11_Pro_Max || IS_IPHONE_12_Pro || IS_IPHONE_12_Pro_Max)

#define STATUS_BAR ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_11 == YES || IS_IPHONE_11_Pro == YES || IS_IPHONE_11_Pro_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 50 : 20.0)

// 状态栏高度
#define STATUS_BAR_HEIGHT ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_11 == YES || IS_IPHONE_11_Pro == YES || IS_IPHONE_11_Pro_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 44.0 : 20.0)

// 导航栏高度
#define NAVIGATION_BAR_HEIGHT  ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_11 == YES || IS_IPHONE_11_Pro == YES || IS_IPHONE_11_Pro_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 88.0 : 64.0)

// tabBar高度
#define TAB_BAR_HEIGHT ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_11 == YES || IS_IPHONE_11_Pro == YES || IS_IPHONE_11_Pro_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 83.0 : 49.0)

// home indicator
#define kHomeIndicatorHeight ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_11 == YES || IS_IPHONE_11_Pro == YES || IS_IPHONE_11_Pro_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 34.0 : 0)

#define kHOME_HEIGHT ((iPhoneX == YES || IS_IPHONE_Xr == YES || IS_IPHONE_Xs == YES || IS_IPHONE_Xs_Max == YES || IS_IPHONE_11 == YES || IS_IPHONE_11_Pro == YES || IS_IPHONE_11_Pro_Max == YES || IS_IPHONE_12_Pro == YES || IS_IPHONE_12_Pro_Max == YES) ? 24.0 : 0)

#define PhoneSystenType @"iOS"
#define AppCurrentVersionString [NSString stringWithFormat:@"V%@", [UIApplication sharedApplication].appVersion]
#define UserDefaultLoginToken [[NSUserDefaults standardUserDefaults] objectForKey:kUserDefaultLoginToken]

#define ShowToast(string) [CommonUtils MBProgressHUDWithTitle:string]
#define ShowToastWithDelay(string, delay) [CommonUtils MBProgressHUDWithTitle:string delayTime:delay]

#pragma mark - form
#define XGSFormTag 155158
#define XGSForm_BorderColorKey @"XGSForm_BorderColorKey"
#define XGSForm_BorderStyleKey @"XGSForm_BorderStyle"
#define XGSForm_LineColorKey @"XGSForm_LineColorKey"
#define XGSForm_LineStyleKey @"XGSForm_LineStyle"
#define XGSForm_ISDragAction @"XGSForm_ISDragAction"

//字符串是否为空
#define kStringIsEmpty(str) ([str isKindOfClass:[NSNull class]] || str ==  nil || [str length] < 1 ? YES : NO )
//数组是否为空
#define kArrayIsEmpty(array) (array == nil || [array isKindOfClass:[NSNull  class]] || array.count == 0)
//字典是否为空
#define kDictIsEmpty(dic) (dic == nil || [dic isKindOfClass:[NSNull class]]  || dic.allKeys == 0)
//是否是空对象
#define kObjectIsEmpty(_object) (_object == nil \
|| [_object isKindOfClass:[NSNull class]] \
|| ([_object respondsToSelector:@selector(length)] && [(NSData  *)_object length] == 0) \
|| ([_object respondsToSelector:@selector(count)] && [(NSArray  *)_object count] == 0))

