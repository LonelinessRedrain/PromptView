//
//  PromptMultipleSelectTableViewCell.m
//  XG_Student
//
//  Created by 高志炎(Intretech) on 2022/11/18.
//  Copyright © 2022 intretech. All rights reserved.
//

#import "PromptMultipleSelectTableViewCell.h"

@implementation PromptMultipleSelectTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self configSubviews];
    }
    return self;
}

#pragma mark - Private Method
- (void)configSubviews {
    self.contentView.backgroundColor = [UIColor colorWithHexString:@"#FAFAFB"];
    
    [self.contentView addSubview:self.selectImageView];
    [self.selectImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-FIT_LENGTH_PT(13));
        make.centerY.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(23, 23));
    }];
    
    [self.contentView addSubview:self.nameLabel];
    [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(FIT_LENGTH_PT(13));
        make.right.equalTo(self.selectImageView.mas_left).offset(-FIT_LENGTH_PT(15));
        make.centerY.equalTo(self.contentView);
    }];
    
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = KProjectGrayBorderColor;
    [self.contentView addSubview:lineView];
    self.lineView = lineView;
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.contentView.mas_bottom);
        make.left.equalTo(self.contentView.mas_left).offset(FIT_LENGTH_PT(13));
        make.right.equalTo(self.contentView.mas_right).offset(-FIT_LENGTH_PT(13));
        make.height.mas_equalTo(FIT_LENGTH_PT(0.5));
    }];
}

#pragma mark - Getter
- (UILabel *)nameLabel {
    if (!_nameLabel) {
        _nameLabel = [[UILabel alloc] init];
        _nameLabel.textColor = kProjectTextColor;
        _nameLabel.font = [UIFont systemFontOfSize:FIT_LENGTH_PT(15)];
    }
    return _nameLabel;
}

- (UIImageView *)selectImageView {
    if (!_selectImageView) {
        _selectImageView = [[UIImageView alloc] init];
    }
    return _selectImageView;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
