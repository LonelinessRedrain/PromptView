//
//  CommonUtils.m
//  XG_Student
//
//  Created by 12990 on 2019/3/13.
//  Copyright © 2019 intretech. All rights reserved.
//

#import "CommonUtils.h"
//#import "RealReachability.h"
#import <SystemConfiguration/CaptiveNetwork.h>
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <Photos/Photos.h>
//#import <UMCommon/UMCommon.h>
//#import <UMCommon/MobClick.h>
//#import "MBProgressHUD.h"

//#import "DoraemonAppInfoUtil.h"
#define IFF_UP          0x1             /* interface is up */
#define IP_ADDR_IPv4    @"ipv4"
#define IP_ADDR_IPv6    @"ipv6"


@implementation CommonUtils

#pragma mark - Foundation

+ (NSString *)currentTimestamp {
     return [NSString stringWithFormat:@"%lld", (UInt64)([[NSDate date] timeIntervalSince1970]*1000)];
}

+ (NSString *)currentTimestampBySecond {
     return [NSString stringWithFormat:@"%lld", (UInt64)([[NSDate date] timeIntervalSince1970])];
}

+ (NSString *)currentTimeStringWithDateFormat:(nullable NSString *)dateFormat {
    NSDate *date = [NSDate date];
    return [self timeStringWitDate:date dateFormat:dateFormat];
}

+ (NSString *)timeStringWitDate:(NSDate *)date dateFormat:(nullable NSString *)dateFormat {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    formatter.locale = [NSLocale systemLocale];
    if ([CommonUtils isEmptyString:dateFormat]) {
        dateFormat = @"yyyy/MM/dd HH:mm:ss SSS";
    }
    [formatter setDateFormat:dateFormat];
    return [formatter stringFromDate:date];
}

+ (NSString *)getOtherTimeStrWithString:(NSString *)formatTime {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    [formatter setTimeZone:timeZone];
    NSDate* date = [formatter dateFromString:formatTime];
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue];
    return [NSString stringWithFormat:@"%ld",(long)timeSp];
}

+ (NSString *)timestampWithDate:(NSDate *)date {
    return [NSString stringWithFormat:@"%lld", (UInt64)([date timeIntervalSince1970])];
}

+ (NSDate *)dateWithTimestamp:(NSString *)timestamp {
    return [NSDate dateWithTimeIntervalSince1970:[timestamp longLongValue]];
}

+ (NSString *)fetchTimeStringWithDateFormat:(nullable NSString *)dateFormat {
    NSTimeInterval interval = [dateFormat doubleValue];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:interval];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setLocale:[NSLocale currentLocale]];
    [formatter setDateFormat:@"MM月dd号 hh:mm"];
    NSString *_date = [formatter stringFromDate:date];
    
    return _date;
}

+ (NSDate *)dateWithDatestring:(NSString *)dateString dateFormat:(NSString *)dateFormat {
     //设置转换格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    [formatter setDateFormat:dateFormat];
    //NSString转NSDate
    NSDate *date=[formatter dateFromString:dateString];
    return date;
}

+ (NSString *)convertSecondsToHHMMSS:(NSInteger)seconds {
    
    //format of hour
    NSString *str_hour = [NSString stringWithFormat:@"%02ld",(long)seconds/3600];
    //format of minute
    NSString *str_minute = [NSString stringWithFormat:@"%02ld",(long)(seconds%3600)/60];
    //format of second
    NSString *str_second = [NSString stringWithFormat:@"%02ld",(long)seconds%60];
    //format of time
    NSString *format_time = [NSString stringWithFormat:@"%@:%@:%@",str_hour,str_minute,str_second];

    return format_time;

}

+ (void)previewWithImage:(UIImage *)image {
    // image为将打印的图片
    // 预览效果
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    [[UIApplication sharedApplication].delegate.window addSubview:scrollView];
    CGFloat width = SCREEN_WIDTH;
    CGFloat height = SCREEN_WIDTH * (SCREEN_HEIGHT / SCREEN_WIDTH);
    scrollView.contentSize = CGSizeMake(width, height);
    UIImageView *iv = [[UIImageView alloc] initWithImage:image];
    iv.backgroundColor = [UIColor blackColor];
    iv.frame = CGRectMake(0, 0, width, height);
    iv.contentMode = UIViewContentModeScaleAspectFit;
    iv.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithActionBlock:^(id  _Nonnull sender) {
        [scrollView removeFromSuperview];
    }];
    [iv addGestureRecognizer:tap];
    [scrollView addSubview:iv];
}

+ (void)previewWithImages:(NSMutableArray *)images originalImage:(UIImage *)originalImage {
    // image为将打印的图片
    // 预览效果
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.frame = CGRectMake(0, 400, SCREEN_WIDTH * 2, SCREEN_HEIGHT);
    [[UIApplication sharedApplication].delegate.window addSubview:scrollView];
    
    CGFloat width = SCREEN_WIDTH / 2;
    CGFloat height = 0;
    
    if (originalImage) {
        UIImageView *originalImageView = [[UIImageView alloc] initWithImage:originalImage];
        originalImageView.size = CGSizeMake(width, originalImage.size.height * width / originalImage.size.width);
        originalImageView.frame = CGRectMake(0, 5, originalImageView.size.width, originalImageView.size.height);
        [scrollView addSubview:originalImageView];
    }
    

    for (UIImage *subImage in images) {
        UIImageView *iv = [[UIImageView alloc] initWithImage:subImage];
        iv.userInteractionEnabled = YES;
        CGFloat imageHeight = subImage.size.height * width / subImage.size.width;
        iv.frame = CGRectMake(0, height, width, imageHeight);
        [scrollView addSubview:iv];
        height += imageHeight;
    }
    scrollView.contentSize = CGSizeMake(width * 2, height);
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithActionBlock:^(id  _Nonnull sender) {
        [scrollView removeFromSuperview];
    }];


    [scrollView addGestureRecognizer:tap];
    
    
}


+ (NSString *)pinyinFromChinese:(NSString *)chinese {
    //将NSString装换成NSMutableString
    NSMutableString *pinyin = [chinese mutableCopy];
    //将汉字转换为拼音(带音标)
    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformMandarinLatin, NO);
    //去掉拼音的音标
    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformStripCombiningMarks, NO);
    // 去除拼音间的间隔
    return [pinyin stringByReplacingOccurrencesOfString:@" " withString:@""];
}

+ (NSString *)firstLetterFromChinese:(NSString *)chinese {
    NSString *pinyin = [[self class] pinyinFromChinese:chinese];
    NSString *firstLetter = [pinyin substringToIndex:1];
    return firstLetter;
}

+ (void)userDefaultSetObject:(id)value forKey:(NSString *)defaultName {
    if (![CommonUtils isEmptyString:defaultName]) {
        [[NSUserDefaults standardUserDefaults] setObject:value forKey:defaultName];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

+ (id)userDefaultObjectForKey:(NSString *)defaultName {
    return [[NSUserDefaults standardUserDefaults] objectForKey:defaultName];
}

+ (BOOL)isNullObject:(id)object {
    if (!object || object == nil || object == Nil || object == NULL || [object isEqual:[NSNull null]] || object == (id)kCFNull) {
        return YES;
    } else {
        return NO;
    }
}

+ (BOOL)isEmptyString:(NSString *)string {
    if ([self isNullObject:string]) {
        return YES;
    }
    if (![string isKindOfClass:[NSString class]]) {
        return YES;
    }
    return string.length == 0;

}

+ (BOOL)isEmptyAttributedString:(NSAttributedString *)string {
    if ([self isNullObject:string]) {
        return YES;
    }
    if (![string isKindOfClass:[NSAttributedString class]]) {
        return YES;
    }
    return string.length == 0;
}

//判断内容是否全部为空格 yes 全部为空格 no 不是
+ (BOOL)isEmptyBlankSpace:(NSString *)str {
    if(!str) {
        return true;
    } else {
        //A character set containing only the whitespace characters space (U+0020) and tab (U+0009) and the newline and next line characters (U+000A–U+000D,U+0085).
        NSCharacterSet *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        //Returns a new string made by removing from both ends of the receiver characters contained in a given character set.
        NSString *trimedString = [str stringByTrimmingCharactersInSet:set];
        if([trimedString length] == 0) {
            return true;
        } else {
            return false;
        }
    }
}

+ (BOOL)isPureNumber:(NSString *)string {
    if ([CommonUtils isPureInt:string] || [CommonUtils isPureFloat:string]) {
        return YES;
    }
    return NO;
}

+ (BOOL)isPureInt:(NSString*)string {

    NSScanner* scan = [NSScanner scannerWithString:string];
    int val;
    return[scan scanInt:&val] && [scan isAtEnd];

}

+ (BOOL)isPureFloat:(NSString*)string {

    NSScanner* scan = [NSScanner scannerWithString:string];
    float val;
    return[scan scanFloat:&val] && [scan isAtEnd];

}

+ (NSString *)dealWithSpecialSymbol:(NSString *)oriString {
    NSArray<NSString *> *oriSymbols = @[@"·", @"、", @"﹤", @"﹥", @"“", @"”", @"‘", @"’", @"？", @"，", @"⋯⋯", @"：", @"；", @"——", @"①", @"②", @"③", @"④", @"⑤", @"⑥", @"⑦", @"⑧", @"⑨", @"⑩", @"（", @"）", @"～", @"「", @"」", @"•"];
    NSArray<NSString *> *newSymbols = @[@"-", @",", @"<", @">", @"\"", @"\"", @"\'", @"\'", @"?", @",", @"……", @":", @";", @"----", @"1)", @"2)", @"3)", @"4)", @"5)", @"6)", @"7)", @"8)", @"9)", @"10)", @"(", @")", @"~", @"{", @"}", @""];
    NSString *string = oriString;
    for (int i = 0; i < oriSymbols.count; i++) {
       string = [string stringByReplacingOccurrencesOfString:oriSymbols[i] withString:newSymbols[i]];
    }
    return string;
}

+ (BOOL)isValidPassword:(NSString *)password {
    NSString *numRegex =@"[0-9]*";
    NSPredicate *numPred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", numRegex];
    BOOL isAllNumber = [numPred evaluateWithObject:password];

    NSString *alphabetRegex =@"[a-zA-Z]*";
    NSPredicate *alphabetPred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", alphabetRegex];
    BOOL isAllAlphabet = [alphabetPred evaluateWithObject:password];
    return !isAllNumber && !isAllAlphabet;
}

+ (CGFloat)getMinimumDifferenceABSWithSubtracter:(CGFloat)subtracter minuends:(NSArray<NSNumber *> *)minuends {
    NSMutableArray *differences = [NSMutableArray array];
    for (NSNumber *minuend in minuends) {
        CGFloat difference = fabs(subtracter-minuend.doubleValue);
        [differences addObject:@(difference)];
    }
    CGFloat minDifference = [[differences.copy valueForKeyPath:@"@min.doubleValue"] floatValue];
    return minDifference;
}

+ (void)addContentToPasteboard:(NSString *)string {
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = string;
}

+ (CGFloat)numberByCutToTwoDecimalsWithoutRound:(CGFloat)number {
    return floor((number)*100)/100;
}

+ (NSString *)randomStringWithLength:(int)length {
    // https://stackoverflow.com/questions/2633801/generate-a-random-alphanumeric-string-in-cocoa
    NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString *randomString = [NSMutableString stringWithCapacity: length];
    for (int i=0; i<length; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex: arc4random_uniform([letters length])]];
    }
    
    return randomString;
}

+ (NSString *)randomStringForDataBase {
    return [CommonUtils randomStringWithLength:32];
}

#pragma mark - 系统相关
+ (NSString *)getDeviceUUID {
    NSString *kService = @"kDeviceUUIDMemobirdService";
    NSString *kAccount = @"kDeviceUUIDMemobirdAccount";
    NSString *uuidStr = [YYKeychain getPasswordForService:kService account:kAccount];
    if ([CommonUtils isEmptyString:uuidStr]) {
        CFUUIDRef uuid;
        CFStringRef uuidCFStr;
        uuid = CFUUIDCreate(NULL);
        uuidCFStr = CFUUIDCreateString(NULL, uuid);
        uuidStr =[NSString stringWithFormat:@"%@", uuidCFStr];
        CFRelease(uuidCFStr);
        CFRelease(uuid);
        [YYKeychain setPassword:uuidStr forService:kService account:kAccount];
    }
    return uuidStr;
}

+ (NSString *)getDeviceName {
    return [QMUIHelper deviceName];
}

+ (NSString *)getDeviceVersion {
    return [[UIDevice currentDevice] systemVersion];
}

+ (CGFloat)getBatteryLevel {
    return [[UIDevice currentDevice] batteryLevel];
}

+ (NSInteger)fetchCurrVersion {
    NSString *currentVersion = [[UIApplication sharedApplication].appVersion  stringByReplacingOccurrencesOfString:@"." withString:@""];
    return [currentVersion integerValue];
}

+ (void)openSystemSettingPage {
    NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
    if ([ [UIApplication sharedApplication] canOpenURL:url])
    {
        [[UIApplication sharedApplication] openURL:url];
    }
}

#pragma mark - UIKit
+ (NSArray<UIImageView *> *)getImageViewsFromParentView:(UIView *)view {
    NSMutableArray *array = [NSMutableArray array];
    for (UIView *subView in view.subviews) {
        // 因为子View有滚动条是ImageView，所以 > 100是为了排除滚动条
        if ([subView isKindOfClass:[UIImageView class]] && subView.width > 100 && subView.height > 100) {
            [array addObject:subView];
        }
    }
    return array;
}

+ (UIButton *)buttonWithTitle:(NSString *)title titleColor:(UIColor *)titleColor fontSize:(CGFloat)fontSize target:(id)target action:(SEL)action {
    return [CommonUtils buttonWithTitle:title
                      titleColor:titleColor
                        fontSize:fontSize
                        backgroundColor:[UIColor clearColor]
                           cornerRadius:0.0
                          target:target
                          action:action];
}

+ (UIButton *)buttonWithTitle:(NSString *)title titleColor:(UIColor *)titleColor fontSize:(CGFloat)fontSize backgroundColor:(UIColor *)bgColor cornerRadius:(CGFloat)cornerRadius target:(id)target action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:titleColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:fontSize];
    button.backgroundColor = bgColor;
    button.layer.cornerRadius = cornerRadius;
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

+ (UILabel *)labelWithText:(NSString *)text textColor:(UIColor *)textColor fontSize:(CGFloat)fontSize {
    UILabel *label = [[UILabel alloc] init];
    label.text = text;
    label.textColor = textColor;
    label.font = [UIFont systemFontOfSize:fontSize];
    return label;
}

+ (UIViewController *)topViewController {
    return [self topViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
}

+ (UIViewController *)topViewController:(UIViewController *)rootViewController
{
    if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController *navigationController = (UINavigationController *)rootViewController;
        return [CommonUtils topViewController:[navigationController.viewControllers lastObject]];
    }
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabController = (UITabBarController *)rootViewController;
        return [CommonUtils topViewController:tabController.selectedViewController];
    }
    if (rootViewController.presentedViewController) {
        return [CommonUtils topViewController:rootViewController];
    }
    return rootViewController;
}


+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size {
    return [self createQRCode:text size:size image:[UIImage imageNamed:@"note_qr_logo"]];
}

+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size logoFrame:(CGRect)logoFrame {
    return [self createQRCode:text size:size image:[UIImage imageNamed:@"note_qr_logo"] imageFrame:logoFrame];
}

+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size image:(UIImage *)image {
    CGFloat length = MAX(size.width, size.height);
    if (length <= 0) {
        length = 200; // 默认的二维码边长
    }
    return [self createQRCodeWithText:text size:CGSizeMake(length, length) image:image];
}

+ (UIImage *)createQRCode:(NSString *)text size:(CGSize)size image:(UIImage *)image imageFrame:(CGRect)imageFrame {
    CGFloat length = MAX(size.width, size.height);
    if (length <= 0) {
        length = 200; // 默认的二维码边长
    }
    return [self createQRCodeWithText:text size:CGSizeMake(length, length) image:image imageFrame:imageFrame];
}

+ (UIImage *)createQRCodeWithText:(NSString*)text size:(CGSize)size image:(nullable UIImage *)image {
    // 1. 创建一个二维码滤镜实例(CIFilter)
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 滤镜恢复默认设置
    [filter setDefaults];

    // 2. 给滤镜添加数据
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    // 使用KVC的方式给filter赋值
    [filter setValue:data forKeyPath:@"inputMessage"];

    // 3. 生成二维码
    CIImage *qrImage = [filter outputImage];
    // 转成高清格式
    UIImage *qrcode = [CommonUtils createNonInterpolatedUIImageFromCIImage:qrImage size:size];
    // 添加logo
    if (image) {
        qrcode = [CommonUtils drawImage:image inImage:qrcode];
    }
    return qrcode;
}

+ (UIImage *)createQRCodeWithText:(NSString*)text size:(CGSize)size image:(nullable UIImage *)image imageFrame:(CGRect)frame {
    // 1. 创建一个二维码滤镜实例(CIFilter)
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 滤镜恢复默认设置
    [filter setDefaults];

    // 2. 给滤镜添加数据
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    // 使用KVC的方式给filter赋值
    [filter setValue:data forKeyPath:@"inputMessage"];

    // 3. 生成二维码
    CIImage *qrImage = [filter outputImage];
    // 转成高清格式
    UIImage *qrcode = [CommonUtils createNonInterpolatedUIImageFromCIImage:qrImage size:size];
    // 添加logo
    if (image) {
        qrcode = [CommonUtils drawImage:image imageFrame:frame inImage:qrcode];
    }
    return qrcode;
}

+ (UIImage *)createBarCode:(NSString *)text size:(CGSize)size {
    NSData *data = [text dataUsingEncoding: NSASCIIStringEncoding];
    CIFilter *filter = [CIFilter filterWithName:@"CICode128BarcodeGenerator"];
    [filter setValue:data forKey:@"inputMessage"];
    // 设置生成的条形码的上，下，左，右的margins的值
    [filter setValue:[NSNumber numberWithInteger:0] forKey:@"inputQuietSpace"];
    UIImage *barCodeImage = [CommonUtils createNonInterpolatedUIImageFromCIImage:filter.outputImage size:size];
    return barCodeImage;
}

// 将二维码转成高清的格式
+ (UIImage *)createNonInterpolatedUIImageFromCIImage:(CIImage *)image size:(CGSize)size {
    // 获取CIImage图片的的Frame
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size.width/CGRectGetWidth(extent), size.height/CGRectGetHeight(extent));

    // 1.创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);

    // 2.保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    return [UIImage imageWithCGImage:scaledImage];
}

// 添加logo
+ (UIImage *)drawImage:(UIImage *)newImage inImage:(UIImage *)sourceImage {
    CGSize imageSize; //画的背景 大小
    imageSize = [sourceImage size];
    UIGraphicsBeginImageContextWithOptions(imageSize, NO, 0.0);
    [sourceImage drawAtPoint:CGPointMake(0, 0)];
    //获得 图形上下文
    CGContextRef context=UIGraphicsGetCurrentContext();
    //画 自己想要画的内容(添加的图片)
    CGContextDrawPath(context, kCGPathStroke);
    // 注意logo的尺寸不要太大,否则可能无法识别
    CGRect rect = CGRectMake(imageSize.width / 2 - FIT_LENGTH_PT(imageSize.width * 0.1), imageSize.height / 2 - FIT_LENGTH_PT(imageSize.height * 0.1), FIT_LENGTH_PT(imageSize.width * 0.2), FIT_LENGTH_PT(imageSize.height * 0.2));
//    CGContextAddEllipseInRect(context, rect);
    CGContextClip(context);

    [newImage drawInRect:rect];

    //返回绘制的新图形
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

/// 添加logo
/// @param newImage logo
/// @param frame logo大小
/// @param sourceImage 画布
+ (UIImage *)drawImage:(UIImage *)newImage imageFrame:(CGRect)frame inImage:(UIImage *)sourceImage {
    CGSize imageSize; //画的背景 大小
    imageSize = [sourceImage size];
    UIGraphicsBeginImageContextWithOptions(imageSize, NO, 0.0);
    [sourceImage drawAtPoint:CGPointMake(0, 0)];
    //获得 图形上下文
    CGContextRef context=UIGraphicsGetCurrentContext();
    //画 自己想要画的内容(添加的图片)
    CGContextDrawPath(context, kCGPathStroke);
    // 注意logo的尺寸不要太大,否则可能无法识别
    CGRect rect = frame;
//    CGContextAddEllipseInRect(context, rect);
    CGContextClip(context);

    [newImage drawInRect:rect];

    //返回绘制的新图形
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}
+ (void)rotateAnimationWithView:(UIView *)view {
    CABasicAnimation *rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat:M_PI*2.0];
    rotationAnimation.duration = 1;
    rotationAnimation.repeatCount = HUGE_VALF;
    [view.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
}

#pragma mark - Thrid party

+ (UIBarButtonItem *)backBarButtonItemWithTarget:(id)target action:(SEL)action {
    return [[self class] barButtonItemWithImageName:@"ico_back_unchecked" target:target action:action];
}

+ (UIBarButtonItem *)cancelBarButtonItemWithTarget:(id)target action:(SEL)action {
    return [[self class] barButtonItemWithImageName:@"ico_back_unchecked" target:target action:action];
}

+ (UIBarButtonItem *)barButtonItemWithImageName:(NSString *)imageName target:(id)target action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    UIImage *image = [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [button setImage:image forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 32, 32);
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    return barItem;
}

+ (NSDictionary *)dictionaryFromJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}

+ (NSString *)stringFromDictionary:(NSDictionary *)dict {
    NSError *parseError = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

#pragma mark - file
+ (NSString *)fileSizeFromPath:(NSString *)path {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *fileAttribute = [fm attributesOfItemAtPath:path error:nil];
    NSLog(@"文件大小2 ：%lld", [fileAttribute fileSize]);
    if ([fileAttribute fileSize] / 1024 > 1) {
        if ([fileAttribute fileSize] > 1048576) {
            return [NSString stringWithFormat:@"%0.2fMB", [fileAttribute fileSize] / 1024.0 / 1024.0];
        } else {
            return [NSString stringWithFormat:@"%0.2fKB", [fileAttribute fileSize] / 1024.0];
        }
    }
    return [NSString stringWithFormat:@"%lldB", [fileAttribute fileSize]];
}

+ (NSString *)fileCreateTimestampFromPath:(NSString *)path {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *fileAttribute = [fm attributesOfItemAtPath:path error:nil];
    NSDate *fileCreateDate = [fileAttribute fileCreationDate];
    NSTimeInterval timeInterval = [fileCreateDate timeIntervalSince1970];
    return [NSString stringWithFormat:@"%lld", (long long)timeInterval];
}

+ (NSString *)fileCreateDateFromPath:(NSString *)path {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *fileAttribute = [fm attributesOfItemAtPath:path error:nil];
    
    NSLog(@"文件创建日期2 : %@", [fileAttribute fileCreationDate]);
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd  HH:mm";
    NSString *dateAndTimeString = [formatter stringFromDate:[fileAttribute fileCreationDate]];
    NSLog(@"%@", dateAndTimeString);
    return dateAndTimeString;
}

+ (NSString *)fileNameFromPath:(NSString *)path {
    return [[path lastPathComponent] stringByDeletingPathExtension];
}

#pragma mark - 网络

+ (NSString *)currentWifiSSID {
    NSString *ssid = @"";
    NSArray *ifs = CFBridgingRelease(CNCopySupportedInterfaces());
    for (NSString *ifnam in ifs) {
        NSDictionary *info = CFBridgingRelease(CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam));
        if (info[@"SSID"]) {
            ssid = info[@"SSID"];
            break;
        }
    }
    return ssid;
}

#pragma mark - 版本判断

/// 判断是否是某个系统版本
/// @param versionString 版本字符串
+ (BOOL)isSystemVersionWithVersionString:(NSString *)versionString {
    NSString *currentString = [[UIDevice currentDevice] systemVersion];
    return [currentString isEqualToString:versionString];
}
#pragma mark - 获取ip地址

//获取设备当前网络IP地址

+ (NSString *)getIPAddress {
    NSArray *searchArray = @[ /*IOS_VPN @"/" IP_ADDR_IPv4, IOS_VPN @"/" IP_ADDR_IPv6,*/ @"en0" @"/" @"ipv4", @"en0" @"/" @"ipv6", @"pdp_ip0" @"/" @"ipv4", @"pdp_ip0" @"/" @"ipv6" ];

    NSDictionary *addresses = [CommonUtils getIPAddresses];
    __block NSString *address;
    [searchArray enumerateObjectsUsingBlock:^(NSString *key, NSUInteger idx, BOOL *stop)
        {
            address = addresses[key];
            if(address) *stop = YES;
        } ];
    return address ? address : @"0.0.0.0";
}

+ (NSDictionary *)getIPAddresses
{
    NSMutableDictionary *addresses = [NSMutableDictionary dictionaryWithCapacity:8];

    // retrieve the current interfaces - returns 0 on success
    struct ifaddrs *interfaces;
    if(!getifaddrs(&interfaces)) {
        // Loop through linked list of interfaces
        struct ifaddrs *interface;
        for(interface=interfaces; interface; interface=interface->ifa_next) {
            if(!(interface->ifa_flags & IFF_UP) /* || (interface->ifa_flags & IFF_LOOPBACK) */ ) {
                continue; // deeply nested code harder to read
            }
            const struct sockaddr_in *addr = (const struct sockaddr_in*)interface->ifa_addr;
            char addrBuf[ MAX(INET_ADDRSTRLEN, INET6_ADDRSTRLEN) ];
            if(addr && (addr->sin_family==AF_INET || addr->sin_family==AF_INET6)) {
                NSString *name = [NSString stringWithUTF8String:interface->ifa_name];
                NSString *type;
                if(addr->sin_family == AF_INET) {
                    if(inet_ntop(AF_INET, &addr->sin_addr, addrBuf, INET_ADDRSTRLEN)) {
                        type = IP_ADDR_IPv4;
                    }
                } else {
                    const struct sockaddr_in6 *addr6 = (const struct sockaddr_in6*)interface->ifa_addr;
                    if(inet_ntop(AF_INET6, &addr6->sin6_addr, addrBuf, INET6_ADDRSTRLEN)) {
                        type = IP_ADDR_IPv6;
                    }
                }
                if(type) {
                    NSString *key = [NSString stringWithFormat:@"%@/%@", name, type];
                    addresses[key] = [NSString stringWithUTF8String:addrBuf];
                }
            }
        }
        // Free memory
        freeifaddrs(interfaces);
    }
    return [addresses count] ? addresses : nil;
}

+ (void)requestALAssetsLibraryAuthorizationWithCompletion:(RequestAssetsLibraryAuthCompletion)requestAssetsLibraryAuthCompletion {
    PHAuthorizationStatus authStatus = [PHPhotoLibrary authorizationStatus];
    if (authStatus != PHAuthorizationStatusAuthorized) // 未授权
    {
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            if (status != PHAuthorizationStatusAuthorized)  //已授权
            {
                NSLog(@"用户拒绝访问相册！");
                if (requestAssetsLibraryAuthCompletion) {
                    requestAssetsLibraryAuthCompletion(NO);
                }
            } else {
                NSLog(@"用户允许访问相册！");
                if (requestAssetsLibraryAuthCompletion) {
                    requestAssetsLibraryAuthCompletion(YES);
                }
            }
        }];
    } else {
        requestAssetsLibraryAuthCompletion(YES);
    }
}

#pragma mark - 获取当前屏幕显示的viewcontroller

+ (UIViewController*)currentViewController {
    // Find best view controller
    UIViewController* viewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    return [self findBestViewController:viewController];
}

+ (UIViewController*)findBestViewController:(UIViewController*)viewController {
    if (viewController.presentedViewController) {
        // Return presented view controller
        return [self findBestViewController:viewController.presentedViewController];
        
    } else if ([viewController isKindOfClass:[UISplitViewController class]]) {
        
        // Return right hand side
        UISplitViewController *splitViewController = (UISplitViewController*)viewController;
        if (splitViewController.viewControllers.count > 0)
            return [self findBestViewController:splitViewController.viewControllers.lastObject];
        else
            return viewController;
        
    } else if ([viewController isKindOfClass:[UINavigationController class]]) {
        
        // Return top view
        UINavigationController *navigationController = (UINavigationController*)viewController;
        if (navigationController.viewControllers.count > 0)
            return [self findBestViewController:navigationController.topViewController];
        else
            return viewController;
        
    } else if ([viewController isKindOfClass:[UITabBarController class]]) {
        
        // Return visible view
        UITabBarController *tabBarController = (UITabBarController*)viewController;
        if (tabBarController.viewControllers.count > 0)
            return [self findBestViewController:tabBarController.selectedViewController];
        else
            return viewController;
        
    } else {
        
        // Unknown view controller type, return last child view controller
        return viewController;
    }
}

#pragma mark -  URL Scheme
+ (void)jumpToQQGroupPageWithQQGroupID:(NSString *)qqGroupID {
    NSString* urlString = [NSString stringWithFormat:@"mqqapi://card/show_pslcard?src_type=internal&version=1&uin=%@&key=%@&card_type=group&source=external", qqGroupID, @"44a6e01f2dab126f87ecd2ec7b7e66ae259b30535fd0c2c25776271e8c0ac08f"];
    NSURL *url = [NSURL URLWithString:urlString];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }
}

/// 比较两个浮点数的大小返回的是startValue相对于endValue对比的结果
/// - Parameters:
///   - startValue: startValue
///   - endValue: endValue
///   - position: 两个浮点数的精度
///   - roundingMode: 精度规则
+ (NSComparisonResult)compareStartValue:(CGFloat)startValue endValue:(CGFloat)endValue afterPoint:(int)position roundingMode:(NSRoundingMode)roundingMode {
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:roundingMode scale:position raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
    
    NSDecimalNumber *startDecimal = [[NSDecimalNumber alloc] initWithFloat:startValue];
    NSDecimalNumber *endDecimal = [[NSDecimalNumber alloc] initWithFloat:endValue];

    startDecimal = [startDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];
    endDecimal = [endDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];

    NSComparisonResult result = [startDecimal compare:endDecimal];
    return result;
}

/// 浮点数取精度
/// - Parameters:
///   - floatValue: 数值
///   - position: 精度
///   - roundingMode: 精度规则
+ (CGFloat)floatValue:(CGFloat)floatValue afterPoint:(int)position roundingMode:(NSRoundingMode)roundingMode {
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:roundingMode scale:position raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
    
    NSDecimalNumber *valueDecimal = [[NSDecimalNumber alloc] initWithFloat:floatValue];

    valueDecimal = [valueDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];

    CGFloat tempFloatValue = [valueDecimal floatValue];
    return (((int)(tempFloatValue * 10)) / 10);
}

@end

