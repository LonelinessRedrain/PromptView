//
//  ViewController.m
//  PromptView
//
//  Created by 高志炎(Intretech) on 2023/8/28.
//

#import "ViewController.h"
#import "PromptView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)buttonAction:(id)sender {
    PromptView * promptView = [PromptView promptViewWithTitle:@"这是一个弹窗标题，可以多行文字" message:@"这是弹窗详细信息，可以多行文字" confirmStr:@"确定" confirm:^{
        
    } cancelStr:@"取消" cancel:^{
        
    }];
    [promptView show];
}

@end
